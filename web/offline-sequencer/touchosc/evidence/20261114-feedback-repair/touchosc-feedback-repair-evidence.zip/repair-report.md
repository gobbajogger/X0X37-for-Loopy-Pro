# TouchOSC feedback repair — ROADMAP 105 continuation

The incoming-feedback lifetime repair passes the exercised genuine TouchOSC path. The broader companion qualification remains partial. No merge, ROADMAP, firmware, release, paid licence, physical MIDI or active owner-session action occurred.

## Inputs and ownership

Base: `gobbajogger/X0X37-for-Loopy-Pro@94197fc839b00aff47b98ca02f3c6396e4a6eabf`, root tree `72d28fbc741244d18fa3d18495da16ab0fcb1d24`. Exact Library archives, their SHA-256 values, and ownership reconciliation are in `plan.md` and `source-inputs.json`. The six source files came from the exact GitHub pin; the four original bundled source files match it. Historical author PR808 is closed and names PR864 as the prior source integration. No open TouchOSC PR or matching branch was found. Parent delegated this bounded repair; the original branch and existing checkout are untouched. Live top-level chat inventory is unavailable; the shared coordination ref returned 404, not proof of retired worker inactivity. This worker owns only the three scoped changed files in the separate candidate directory, for intended branch `chat/touchosc-feedback-lifetime-20261114`.

Current maintained policy was read at `nightly@66073c68dd80d51a7053432c2c161a8b720a1341`; current delegation explicitly authorizes this Work/Codex repair and verification. The source base is 1232 commits ahead of that old nightly ref. Current main@035026fe diverges from the source base (48 commits on main and89 on the base side), despite all six scoped TouchOSC blobs matching. Neither ref is a suitable focused PR base for this exact starting pin. The source lane `lane/026-combined-20261112` was then verified at the exact94197fc8 base. A focused PR can target that lane without including unrelated firmware history or updating its ref. No integration authority is inferred.

## Change and its purpose

Incoming MIDI previously painted key colours but never entered the locally held-note table. The existing disarm path therefore cleared only local notes, leaving CH2 feedback highlighted after switching to CH3. `resetFeedback()` now clears the sixteen allowed key colours and resets the feedback line during init/disarm. RELEASE, both channel controls (including clamps), and a local hold timeout share that path. It runs after exact original-channel local releases; receive-only notes cause no MIDI egress. ARM retains the current observation window. Incoming notes still update while disarmed, with no independent receive-only timeout. Normal overlapping local/incoming events retain their existing last-event colour behavior. Button values, route filtering, hold limit and transport behavior are unchanged.

Changed source: `controller.lua`, `controller.test.lua`, and `README.md`, all under `web/offline-sequencer/touchosc`. The layout, packer and button scripts are unchanged. `source.patch` is the complete delta. `candidate-inputs.json` records exact bytes and Git blob hashes.

## Executed proof

| Check | Outcome |
|---|---|
| New Lua feedback scenarios on original controller | Expected FAIL: seven of eight cases expose missing feedback reset; exit1. `regression-before.log`. |
| Same Lua scenarios plus original controller checks on fixed controller | PASS: all eight new scenarios; original checks also pass; Lua5.1.5, exit0. `regression-after.log`. |
| Packing suite | PASS: four checks; exit0. `packing-after.log`. |
| Generated XML/.tosc | PASS: deterministic packing, decompressed byte equality,47 nodes, embedded controller/button scripts match exact source. |
| Genuine baseline app reproduction | CH2 note60 ON then CH+ reproduces old colour and CH2 message on CH3. Seven behavior/route comparisons matched the defect. A supplemental `modified=false` assertion failed (`true` observed), so this run exits1 and is not reported as an all-pass run. Original on-disk bytes remain unchanged; no save was performed. |
| Genuine repaired `.tosc` | PASS:206 comparisons, exit0. All16 incoming notes, CH+/CH-, RELEASE/repeated RELEASE, late old-channel OFF, live new-channel ON/OFF, velocity0 after highlighted ON, ARM retention, channel clamps, receive-only zero egress, local hold timeout with receive-only notes, exact original-channel ON/OFF, stale pointer release, unchanged transport-loss observation, final reset and unmodified document. `runtime/fixed-feedback-results.json`, run log, datagrams and MCP trace. |
| Genuine repaired XML | PASS: actual File>Open and affected receive→CH+ reset path,8 comparisons, exit0. No echo, button x remains0, document unmodified. `runtime/xml-feedback-results.json`. |

The app is genuine TouchOSC1.5.4.269, official unrestricted desktop trial, ZIP verified against Hexler's published checksum. Lua5.1.5 was built from the official checksum-verified source. Environment and executable identities are in `environment-receipt.json`. Runtime used isolated Xvfb:95, actual XTEST mouse input, and an original loopback UDP Bridge peer. App state was read via its documented local MCP server; no document/control/Lua setters were used. Only mode/log visibility operations and real UI route setup occurred. The corrected candidate has `modified=false` before and after its run. Baseline's dirty flag changed from false to true during its incoming-note/channel sequence, with canUndo=false; its cause was not established in this bounded repair. It does not establish disk mutation. The failed supplemental assertion and trace remain available. Native File>Open briefly blocks MCP while its modal picker is open; a read timed out, then the actual picker was focused and completed normally.

The unchanged historical Lua proof at PR808 comment6632940227 remains historical scoped evidence only. It is not claimed for this changed controller. Unchanged layout presentation/packer provenance is reused; affected controller checks were executed afresh. No firmware build or full repository host-suite result is claimed for this isolated TouchOSC-only repair. The delegated scope calls for affected regressions and reuse of unchanged proof.

## Transport finding and remaining qualification

The receive-only feedback fix does not alter send delivery. Static tracing confirms `release()` sends one Note Off and removes the local entry without receiver acknowledgment or a retry queue. The genuine fixed-app run again observed a bound peer drop the OFF during a loopback outage, no replay in the measured0.3s after restoration, and no recovery from later RELEASE because the entry was gone. These are successful reproductions of an adverse limitation, not safety or reconnect passes. README preserves release-before-app/route/endpoint-change guidance and explains the limitation. No disconnected-delivery promise or behavior change was introduced.

NOT_RUN: genuine OS virtual endpoint disappearance/reappearance (no `/dev/snd/seq`), ALSA/CoreMIDI/IAC enumeration/reconnect, held-note RELEASE and held-note channel changes using independent actual touches, simultaneous local touches/polyphony, outside-release/cancel/focus loss, mobile/iPhone/macOS, physical MIDI/hardware. Mocked regressions verify local original-channel release behavior but do not qualify those actual-input scenarios. The actual timeout test uses one pointer and confirms it remains physically pressed until its real release; this is not multitouch or focus-loss proof. The layout remains labelled UNQUALIFIED because these broader gates remain open.

## Exact generated artifacts

- `.tosc`: SHA-256 `fd7b23ef77ba5b347c384be5a34cb29e64d6f3d69300e86ea164375d2d9d0617`.
- XML: SHA-256 `df1b7077a7b3de598142126173c6e96fdba697828fca7ef44b0b6f222e7618c7`.
- Controller: Git blob `4b8ab17354c4fc99a1b5316c4eb39af53a88c5e8`, SHA-256 `d7ef0b9b7caad60d630241524b9c4f4a72260ad711c168e137c26125976daed7`.
- Test: Git blob `8bf16d6865950da57a105ba7f7103ac4dbf9dc4d`, SHA-256 `bf74fe545da3c2f522310e5293fdc0d69480f06055a046e01901aed1d7ba0791`.
- README: Git blob `fdbc574f84cb5db5a69073e5cf9f097ba167df2c`, SHA-256 `361b4d8d73fc427eed09f118e68a800a1d703e8679e9e576eacc208e4b4c7211`.

## Reproduction

From the repaired source root, run `lua5.1 web/offline-sequencer/touchosc/controller.test.lua` and `python3 web/offline-sequencer/touchosc/pack.test.py`. Generate new files with `python3 web/offline-sequencer/touchosc/pack.py --output <new-path>.tosc` and again with `.xml`; existing output paths are refused. Open the exact candidate in genuine TouchOSC. Enable MCP port13579, set the app to the recorded1024×768 window at100,50 with log visible, and control-surface mode. Route MIDI1 send/receive to `<Bridge 1>` with Bridge1 host127.0.0.1, other MIDI connections disabled. Start `runtime/bridge_peer.py`; run `runtime/qualify_feedback.py fixed`. This script assumes initial CH2 and the recorded geometry. Open XML separately using File>Open, enter control-surface mode, then run `runtime/qualify_xml_feedback.py`. The included harness paths use this task workspace; adjust paths/display/ports for another isolated workspace. Do not redistribute the third-party runtime. Screenshots used for internal inspection are excluded from the Library evidence archive.

Independent design review is in `design-review.md`. Final code/evidence review, remote source-delivery receipt and successor handoff are recorded separately when completed. No Sol or formal PR review is claimed.
