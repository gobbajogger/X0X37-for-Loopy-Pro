# TouchOSC incoming-feedback repair — ROADMAP 105 continuation

Source owner: this delegated Work/Codex stage, limited to `web/offline-sequencer/touchosc`. Base: `gobbajogger/X0X37-for-Loopy-Pro@94197fc839b00aff47b98ca02f3c6396e4a6eabf`. Intended isolated branch: `chat/touchosc-feedback-lifetime-20261114`. No merge, ROADMAP, firmware, device, paid licence, or active-session changes.

Qualification consumed: `touchosc-runtime-qualification-94197fc8-20261114.zip`, SHA-256 `6a9d0753f31e430af7e0301abdca292d53f48ae90451680a87b3aff9840a25b3`; original bundle SHA-256 `4e0263698c8825835ce1bdd566ebb73bab903819925e5ce57e72833e3bee733a`. All six scoped source blobs recovered from the exact GitHub pin; the four bundled source files match. Existing source author is the connected default account gobbajogger. Historical PR808 is closed, not merged, with its final notice identifying source already present via PR864. No open TouchOSC PR or matching branch was found. The parent explicitly assigned this repair stage; preserve the original writer branch and untouched workspace checkout. The coordination/merge-queue ref returns 404, so no shared ledger mutation is attempted. No top-level thread-list/creation tool is exposed here.

Root cause: incoming MIDI paints controls without joining local `active`. `disarm()` releases and clears only locally active notes. Therefore receive-only colour and message text outlive RELEASE, channel changes, and timeout.

Proposed state preview (existing layout and controls retained):

| Action | Route | Feedback / key colours |
|---|---|---|
| CH2 Note60 ON | unchanged | CH2 note60 shown, key highlighted |
| CH+ | DISARMED / CH3 | neutral feedback line, all keys neutral |
| late CH2 OFF | unchanged | ignored |
| CH3 Note60 ON/OFF | unchanged | current-channel feedback updates normally |
| RELEASE / timeout | DISARMED | neutral feedback line and keys |
| ARM | ARMED | existing current-channel feedback retained |

The reset uses the existing neutral `No incoming MIDI observed` presentation. It establishes a new observation window after init/disarm, including same-channel RELEASE and clamped channel controls. It does not send MIDI for received notes, reset button values, retry transport, or promise delivery while disconnected. Local held notes still release exactly once on their original channel before route changes. Normal local/incoming overlap retains the existing last-event colour behavior; source ownership tracking outside reset is not expanded.

Execution: independently review this state preview; add regressions and observe failure on unchanged controller; implement a common feedback reset through init/disarm; rerun changed controller and packing checks; regenerate deterministic XML/.tosc; use genuine TouchOSC 1.5.4.269 in an isolated task display and loopback Bridge peer to exercise the affected callbacks and zero-echo behavior; independently review exact fixed input closure and evidence; deliver scoped source on isolated branch and read back hashes. Historical passing scenarios may be cited with their old source closure; changed controller proof must run again.

Acceptance: reproduced stale CH2→CH3 feedback clears in actual runtime, affected mocked regressions pass, generated scripts match fixed source, independent review has no unresolved blocking findings, exact source/artifact hashes returned. Endpoint disappear/reappear, held-note independent-touch RELEASE/channel changes, multitouch and focus/cancel remain explicitly UNRUN unless the necessary actual input path is exercised. Preserve lost-OFF observation and release-before-route-change guidance. Parent receives precise successor handoff if no top-level Work/Codex creation tool exists.

Source-lane reconciliation: `lane/026-combined-20261112` is still exactly94197fc839b00aff47b98ca02f3c6396e4a6eabf. It is the review-PR target; do not use divergent main or old nightly. The source author's historical branch remains untouched.
