# Independent review of the incoming-feedback repair proposal

Verdict: approved for implementation within the stated scope. No blocking design finding.

Reviewer: a separate Codex subagent. This is an independent source and proposal review, not a Sol review, formal PR review, runtime pass, release approval, or claim that the full compound-engineering multi-reviewer pipeline ran. The source was inspected without edits. No commands generated artifacts, ran tests, accessed a device, or wrote GitHub state in this pass.

## Inputs and scope

Read `plan.md` in this evidence directory; `qualification/qualification-report.md` from the supplied qualification extraction; and the six scoped TouchOSC files in `/workspace/touchosc-repair/web/offline-sequencer/touchosc`. The source scope is `gobbajogger/X0X37-for-Loopy-Pro@94197fc839b00aff47b98ca02f3c6396e4a6eabf`, as supplied by the parent. The plan records qualification ZIP SHA-256 `6a9d0753f31e430af7e0301abdca292d53f48ae90451680a87b3aff9840a25b3` and original ZIP SHA-256 `4e0263698c8825835ce1bdd566ebb73bab903819925e5ce57e72833e3bee733a`; I did not independently rehash those ZIPs in this proposal pass.

The recovered scope is not a Git checkout. Its `AGENTS.md` was read. Referenced task/writing skills and feature registry were absent there; matching project instructions were read from `/workspace/X0X37-for-Loopy-Pro`, solely for workflow and writing guidance. They were not substituted for the pinned TouchOSC source. Current action-specific parent instructions govern this report-only review. The existing feature registry identifies TouchOSC as an existing partial source feature.

## Why the proposal is sound

`onReceiveMIDI` paints the selected-channel pad and feedback line but does not enter `active`. `disarm` releases only `active` notes. Thus a receive-only highlight has no clearing path at RELEASE, channel change, or a local-note timeout. The qualification report reproduces the same CH2 note60 ON, CH+ to CH3 mismatch. A common presentation reset used by `init` and `disarm` addresses that root cause without claiming received notes are locally held.

The reset should neutralize every allowed note control and the feedback line. Iterating the existing `allowed` set is sufficient for all twelve chromatic and four drum controls; `colour` already tolerates absent controls. `disarm` must retain the existing local release pass before this reset and before a channel mutation. Received-only notes must never cause sendMIDI. The root notification flow already routes RELEASE, both channel controls, and the safety timeout through disarm, so one common reset prevents inconsistent lifetimes.

The layout, labels, targets, routing, and ARM behavior can remain unchanged. The existing neutral text is understandable as the start of the new observation window if that lifetime is documented. Same-channel RELEASE and clamped channel controls also clear feedback by design. ARM preserves current feedback, and incoming selected-channel notes remain visible while disarmed, consistent with existing receive behavior. A late old-channel OFF is ignored by the existing channel filter.

The proposal explicitly retains last-event colour behavior when local and received activity overlap. This is a bounded repair, not a new source-tracking model. It does not change button x values, so the remaining held-touch/input cases must retain their qualification limits.

## Checks the implementation and final evidence need

- Show the new regression failing against the unchanged controller, then passing against the fixed controller.
- Cover receive-only highlights on multiple pads, including a drum, and an out-of-pad valid note that changes only feedback text. Verify init and disarm clear them.
- Cover CH+ and CH-, RELEASE while already disarmed, channel boundary clamps, and timeout triggered by an actually held local note. Verify ARM retains current feedback.
- Check late old-channel OFF, new-channel ON/OFF, and Note-On velocity 0 after a highlighted ON.
- Assert received-only reset emits no MIDI and does not mutate button x. For mixed local and received activity, assert exact original-channel local OFF count and no received-note OFF.
- Check generated XML and compressed .tosc embed the fixed controller exactly; preserve the packer's output-refusal behavior.
- In genuine TouchOSC, repeat the affected receive callback / control reset path on the regenerated candidate, with visible control state and a live virtual receive positive control. Count outgoing peer packets to substantiate zero echo.

A plain receive-only highlight does not time out under this plan: `update` considers local `active` entries only. The evidence should say a local hold timeout also clears received feedback, rather than imply incoming feedback has its own ten-second expiry.

## Limits that remain

This design review neither verifies the fixed code nor transfers historical controller-specific runtime proof to it. No runtime, mocked test, build, packaging, hash-closure, branch-delivery, or endpoint-lifecycle result was produced here. The final pass must review the actual diff and exact generated/evidence hashes.

The reported dropped OFF during a UDP receiver outage remains a transport limitation. Do not add retries, reconnect replay, or delivery promises under this proposal. Preserve release-before-endpoint/route/application-change guidance. Actual endpoint disappearance/reappearance, independent-touch held-note RELEASE/channel changes, multitouch, focus/cancel, mobile/macOS, and physical-device behavior remain qualified only to the extent separately exercised; otherwise label them UNRUN.
