"""Local virtual MIDI test peer for TouchOSC Bridge. No system MIDI devices.
Protocol reference: velolala/touchosc2midi commit 866a5657eb15431484152991136c4f10f7c6764a
This original fixture records actual loopback datagrams from the unmodified app.
It does not emulate TouchOSC or invoke its Lua callbacks.
"""
import socket,json,threading,time,pathlib,http.server
events=[];lock=threading.Lock();enabled=True
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.bind(('127.0.0.1',12101))
log=pathlib.Path('/workspace/touchosc-repair-evidence/runtime/bridge-datagrams.jsonl')
def record(d):
 d['at']=time.time()
 with lock:
  events.append(d)
  with log.open('a') as f: f.write(json.dumps(d)+'\n')
def recv():
 global enabled
 while True:
  b,a=s.recvfrom(65536)
  if not enabled: record({'direction':'DROPPED','hex':b.hex(),'peer':a});continue
  d={'direction':'RX','hex':b.hex(),'peer':a}
  if b.startswith(b'/midi\0\0\0,m\0\0') and len(b)==16: d['midi']=[b[15],b[14],b[13]]
  record(d)
  if b.startswith(b'/ping\0'): s.sendto(b'/ping\0\0\0,\0\0\0',('127.0.0.1',12102))
threading.Thread(target=recv,daemon=True).start()
class H(http.server.BaseHTTPRequestHandler):
 def log_message(self,*a): pass
 def do_GET(self):
  with lock: b=json.dumps(events).encode()
  self.send_response(200);self.end_headers();self.wfile.write(b)
 def do_POST(self):
  global enabled
  d=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
  if 'enabled' in d: enabled=d['enabled'];record({'event':'peer-enabled','enabled':enabled})
  if 'midi' in d:
   a,b,c=d['midi'];assert all(isinstance(i,int) and 0<=i<=255 for i in [a,b,c]);msg=b'/midi\0\0\0,m\0\0'+bytes([0,c,b,a]);s.sendto(msg,('127.0.0.1',12102));record({'direction':'TX','hex':msg.hex(),'midi':d['midi']})
  self.send_response(200);self.end_headers();self.wfile.write(b'{}')
http.server.HTTPServer(('127.0.0.1',13580),H).serve_forever()
