import sys,time,json,pathlib,urllib.request
sys.path.insert(0,'/workspace/touchosc-repair-tools/python')
from Xlib import display,X
from Xlib.ext.xtest import fake_input
from mcp import call,payload
D=display.Display(':95');doc=payload(call('get_document'));controls={c['name']:c for c in doc['root']['children']};results=[]
def peer(d=None):
 r=urllib.request.Request('http://127.0.0.1:13580/',data=json.dumps(d).encode() if d is not None else None,headers={'Content-Type':'application/json'});return json.load(urllib.request.urlopen(r))
def received(): return [e['midi'] for e in peer() if e.get('direction')=='RX' and 'midi' in e]
def data(n): return payload(call('get_control',{'id':controls[n]['id']}))
def text(n): return data(n)['values']['text']['current']
def colour(n): return data(n)['properties']['color']['value']
def rec(n,obs,exp):
 d={'case':n,'observed':obs,'expected':exp,'status':'PASS' if obs==exp else 'FAIL'};results.append(d);print(d,flush=True)
 if obs!=exp: raise AssertionError(d)
def down(n):
 f=controls[n]['frame'];x=round(441.3+(f['x']+f['w']/2)*.71125);y=round(50+(f['y']+f['h']/2)*.71125)
 fake_input(D,X.MotionNotify,x=x,y=y);fake_input(D,X.ButtonPress,1);D.sync();time.sleep(.07)
def up(): fake_input(D,X.ButtonRelease,1);D.sync();time.sleep(.07)
def click(n): down(n);up()
def inject(msg): peer({'midi':msg});time.sleep(.12)
on={'r':.55,'g':.9,'b':.76,'a':1};off={'r':.16,'g':.25,'b':.3,'a':1}
notes=[*range(60,72),36,38,42,46]
mode=sys.argv[1]
neutral='No incoming MIDI observed'
def cleared(label):
 rec(label+' feedback',text('feedback'),neutral)
 for n in notes: rec(label+' colour '+str(n),colour('note_'+str(n)),off)
def snap(label):
 import subprocess
 subprocess.run(['import','-display',':95','-window','root',str(pathlib.Path(__file__).parent/(mode+'-'+label+'.png'))],check=True)
try:
 rec('initial CH2 route',text('route'),'DISARMED / MIDI CH 2 / connection 1')
 k=len(received())
 inject([0x91,60,99]);rec('real receive CH2 note60 ON',colour('note_60'),on)
 rec('real receive CH2 line',text('feedback'),'Received CH 2 note 60 velocity 99')
 rec('incoming leaves button unpressed',data('note_60')['values']['x']['current'],0)
 snap('before-channel')
 click('channel_up');rec('CH+ disarms and selects CH3',text('route'),'DISARMED / MIDI CH 3 / connection 1')
 if mode=='baseline':
  rec('reproduced defect: CH2 colour remains on CH3',colour('note_60'),on)
  rec('reproduced defect: CH2 line remains on CH3',text('feedback'),'Received CH 2 note 60 velocity 99')
  snap('after-channel')
 else:
  cleared('CH+ reset');snap('after-channel')
  inject([0x81,60,0]);cleared('late CH2 OFF ignored')
  inject([0x92,60,77]);rec('new CH3 ON is live',colour('note_60'),on)
  rec('new CH3 line',text('feedback'),'Received CH 3 note 60 velocity 77')
  inject([0x82,60,9]);rec('new CH3 OFF clears',colour('note_60'),off)
  inject([0x92,60,77]);inject([0x92,60,0]);rec('velocity-zero clears highlighted key',colour('note_60'),off)
  rec('velocity-zero feedback',text('feedback'),'Received CH 3 note 60 velocity 0')
  for n in notes:
   inject([0x92,n,95]);rec('receive ON '+str(n),colour('note_'+str(n)),on)
   rec('receive leaves x '+str(n),data('note_'+str(n))['values']['x']['current'],0)
  inject([0x92,59,77]);click('arm')
  rec('ARM retains current feedback',text('feedback'),'Received CH 3 note 59 velocity 77')
  click('disarm');cleared('RELEASE all incoming')
  click('disarm');cleared('repeated RELEASE')
  inject([0x92,36,95]);click('channel_down');cleared('CH- reset')
  rec('CH- selects CH2',text('route'),'DISARMED / MIDI CH 2 / connection 1')
  click('channel_down');inject([0x90,60,95]);click('channel_down');cleared('CH1 clamp reset')
  for _ in range(15): click('channel_up')
  inject([0x9F,71,95]);click('channel_up');cleared('CH16 clamp reset')
  for _ in range(14): click('channel_down')
  rec('receive-only reset paths zero MIDI egress',received()[k:],[])
  # The same single pointer genuinely holds a local note while MIDI is received.
  click('arm');k=len(received());down('note_61')
  inject([0x91,60,95]);inject([0x91,36,95]);time.sleep(10.1)
  rec('local timeout original-channel ON/OFF',received()[k:],[[0x91,61,100],[0x81,61,0]])
  rec('timeout disarms',text('route'),'DISARMED / MIDI CH 2 / connection 1')
  cleared('local timeout feedback reset')
  rec('timeout does not synthesize pointer release',data('note_61')['values']['x']['current'],1)
  up();rec('real pointer release restores x',data('note_61')['values']['x']['current'],0)
  rec('late pointer release no duplicate MIDI',received()[k:],[[0x91,61,100],[0x81,61,0]])
  # Transport characterization only: bound UDP peer drops OFF, no OS endpoint disappears.
  click('arm');k=len(received());down('note_60');peer({'enabled':False});up();peer({'enabled':True});time.sleep(.3)
  rec('transport limitation unchanged: no replay after lost OFF',received()[k:],[[0x91,60,100]])
  click('disarm');rec('later RELEASE cannot recover cleared local entry',received()[k:],[[0x91,60,100]])
  cleared('final disarm')
 rec('document remains unmodified',payload(call('get_document'))['modified'],False)
 print('SCRIPT LOG',json.dumps(payload(call('get_log',{'tab':'SCRIPT','lines':200}))))
finally:
 up();pathlib.Path(__file__).with_name(mode+'-feedback-results.json').write_text(json.dumps(results,indent=2)+'\n')
