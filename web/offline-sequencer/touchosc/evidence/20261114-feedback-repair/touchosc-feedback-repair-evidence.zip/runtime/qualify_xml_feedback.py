import sys,time,json,pathlib,urllib.request
sys.path.insert(0,'/workspace/touchosc-repair-tools/python')
from Xlib import display,X
from Xlib.ext.xtest import fake_input
from mcp import call,payload
D=display.Display(':95');doc=payload(call('get_document'));controls={c['name']:c for c in doc['root']['children']};results=[]
def peer(d=None):
 r=urllib.request.Request('http://127.0.0.1:13580/',data=json.dumps(d).encode() if d is not None else None,headers={'Content-Type':'application/json'});return json.load(urllib.request.urlopen(r))
def received(): return [e['midi'] for e in peer() if e.get('direction')=='RX' and 'midi' in e]
def data(n): return payload(call('get_control',{'id':controls[n]['id']}))
def text(n): return data(n)['values']['text']['current']
def colour(n): return data(n)['properties']['color']['value']
def rec(n,obs,exp):
 d={'case':n,'observed':obs,'expected':exp,'status':'PASS' if obs==exp else 'FAIL'};results.append(d);print(d,flush=True)
 if obs!=exp: raise AssertionError(d)
def down(n):
 f=controls[n]['frame'];x=round(441.3+(f['x']+f['w']/2)*.71125);y=round(50+(f['y']+f['h']/2)*.71125)
 fake_input(D,X.MotionNotify,x=x,y=y);fake_input(D,X.ButtonPress,1);D.sync();time.sleep(.07)
def up(): fake_input(D,X.ButtonRelease,1);D.sync();time.sleep(.07)
def click(n): down(n);up()
def inject(msg): peer({'midi':msg});time.sleep(.12)
on={'r':.55,'g':.9,'b':.76,'a':1};off={'r':.16,'g':.25,'b':.3,'a':1}
notes=[*range(60,72),36,38,42,46]
try:
 rec('XML initial route',text('route'),'DISARMED / MIDI CH 2 / connection 1')
 k=len(received());inject([0x91,60,99]);rec('XML actual receive highlights',colour('note_60'),on)
 click('channel_up');rec('XML CH+ route',text('route'),'DISARMED / MIDI CH 3 / connection 1')
 rec('XML CH+ clears incoming highlight',colour('note_60'),off)
 rec('XML CH+ clears previous-channel feedback',text('feedback'),'No incoming MIDI observed')
 rec('XML no echo or received-note OFF',received()[k:],[])
 rec('XML button remains unpressed',data('note_60')['values']['x']['current'],0)
 rec('XML modified flag',payload(call('get_document'))['modified'],False)
finally:
 up();pathlib.Path(__file__).with_name('xml-feedback-results.json').write_text(json.dumps(results,indent=2)+'\n')
