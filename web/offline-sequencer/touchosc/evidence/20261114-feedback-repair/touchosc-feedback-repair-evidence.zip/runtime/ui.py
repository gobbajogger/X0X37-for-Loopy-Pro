import os,sys,time,json,subprocess
sys.path.insert(0,'/workspace/touchosc-repair-tools/python')
from Xlib import display,X,XK
from Xlib.ext.xtest import fake_input
D=display.Display(':95')
def click(x,y):
 fake_input(D,X.MotionNotify,x=x,y=y);fake_input(D,X.ButtonPress,1);D.sync();time.sleep(.07);fake_input(D,X.ButtonRelease,1);D.sync();time.sleep(.15)
def key(name,ctrl=False):
 if ctrl: fake_input(D,X.KeyPress,D.keysym_to_keycode(XK.string_to_keysym('Control_L')))
 c=D.keysym_to_keycode(XK.string_to_keysym(name));fake_input(D,X.KeyPress,c);fake_input(D,X.KeyRelease,c)
 if ctrl: fake_input(D,X.KeyRelease,D.keysym_to_keycode(XK.string_to_keysym('Control_L')))
 D.sync();time.sleep(.2)
def shot(name):
 subprocess.run(['import','-display',':95','-window','root','/workspace/touchosc-repair-evidence/runtime/'+name+'.png'],check=True)
for a in json.loads(sys.argv[1]):
 if a[0]=='click': click(*a[1:])
 elif a[0]=='key': key(*a[1:])
 elif a[0]=='shot': shot(a[1])
 elif a[0]=='down': fake_input(D,X.MotionNotify,x=a[1],y=a[2]);fake_input(D,X.ButtonPress,1);D.sync()
 elif a[0]=='up': fake_input(D,X.ButtonRelease,1);D.sync()
 elif a[0]=='wait': time.sleep(a[1])
 elif a[0]=='type':
  for c in a[1]:
   kc,index=list(D.keysym_to_keycodes(ord(c)))[0]
   if index%2: fake_input(D,X.KeyPress,D.keysym_to_keycode(XK.string_to_keysym('Shift_L')))
   fake_input(D,X.KeyPress,kc);fake_input(D,X.KeyRelease,kc)
   if index%2: fake_input(D,X.KeyRelease,D.keysym_to_keycode(XK.string_to_keysym('Shift_L')))
   D.sync();time.sleep(.012)
 print(a,flush=True)
