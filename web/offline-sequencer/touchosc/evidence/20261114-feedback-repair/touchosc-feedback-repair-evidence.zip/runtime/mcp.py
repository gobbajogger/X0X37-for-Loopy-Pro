import json,urllib.request,datetime,pathlib,sys,os
TRACE=pathlib.Path('/workspace/touchosc-repair-evidence/runtime/mcp-trace.jsonl')
def call(name,args=None):
 assert name in {'get_document','get_control','find_controls','get_log_view','get_log','list_documents','set_log_view','set_mode','insert_log_marker','clear_log'}
 req={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':name,'arguments':args or {}}}
 r=json.loads(urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:'+os.environ.get('TOUCHOSC_MCP_PORT','13579')+'/mcp',data=json.dumps(req).encode(),headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream'}),timeout=15).read())
 with TRACE.open('a') as f: f.write(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':req,'response':r})+'\n')
 return r
def payload(r):
 t=r['result'];return t.get('structuredContent') or json.loads(t['content'][0]['text'])
if __name__=='__main__': print(json.dumps(call(sys.argv[1],json.loads(sys.argv[2]) if len(sys.argv)>2 else {}),indent=2))
