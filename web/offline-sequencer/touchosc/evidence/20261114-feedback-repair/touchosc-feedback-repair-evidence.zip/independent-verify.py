import collections,hashlib,importlib.util,json,pathlib,subprocess,tempfile,xml.etree.ElementTree as ET,zlib
root=pathlib.Path('/workspace/touchosc-repair'); evidence=pathlib.Path('/workspace/touchosc-repair-evidence'); runtime=evidence/'runtime'; scope=root/'web/offline-sequencer/touchosc'
report={'source':[],'hashes':{}}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for row in json.loads((evidence/'candidate-inputs.json').read_text()):
 p=root/row['path']; b=p.read_bytes(); blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert len(b)==row['size'] and sha(p)==row['sha256'] and blob==row['git_blob']
 report['source'].append({**row,'verified':True})
for name in ['touchosc-runtime-qualification-94197fc8-20261114.zip','touchosc-evidence.zip']:
 p=pathlib.Path('/workspace/touchosc-inputs')/name;report['hashes'][name]=sha(p)
assert report['hashes']['touchosc-runtime-qualification-94197fc8-20261114.zip']=='6a9d0753f31e430af7e0301abdca292d53f48ae90451680a87b3aff9840a25b3'
assert report['hashes']['touchosc-evidence.zip']=='4e0263698c8825835ce1bdd566ebb73bab903819925e5ce57e72833e3bee733a'
xml=evidence/'DnBOX-companion-feedback-repair-UNQUALIFIED.xml';tosc=evidence/'DnBOX-companion-feedback-repair-UNQUALIFIED.tosc'
assert zlib.decompress(tosc.read_bytes())==xml.read_bytes()
spec=importlib.util.spec_from_file_location('review_pack',scope/'pack.py');pack=importlib.util.module_from_spec(spec);spec.loader.exec_module(pack)
assert pack.make_xml(scope)==xml.read_bytes() and pack.make_tosc(scope)==tosc.read_bytes()
tree=ET.fromstring(xml.read_bytes());nodes=tree.findall('.//node');assert len(nodes)==47
scripts={}
for node in nodes:
 props={p.findtext('key'):p.findtext('value') for p in node.findall('./properties/property')}
 if 'script' in props:scripts[props['name']]=props['script']
assert len(scripts)==21 and scripts.pop('dnbox_companion')==(scope/'controller.lua').read_text()
assert all(s==(scope/'button.lua').read_text() for s in scripts.values())
report['artifact_checks']={'decompressed_xml_equal':True,'generated_bytes_equal':True,'nodes':len(nodes),'scripts':21,'exact_source_scripts':True}
for p in [xml,tosc,evidence/'source.patch',evidence/'candidate-inputs.json',evidence/'repair-report.md',runtime/'fixed-feedback-results.json',runtime/'xml-feedback-results.json',runtime/'baseline-feedback-results.json',runtime/'bridge-datagrams.jsonl',runtime/'mcp-trace.jsonl',runtime/'qualify_feedback.py',runtime/'qualify_xml_feedback.py',runtime/'bridge_peer.py']:
 report['hashes'][str(p.relative_to(evidence))]=sha(p)
report['results']={}
for stage in ['baseline','fixed','xml']:
 rows=json.loads((runtime/(stage+'-feedback-results.json')).read_text())
 for r in rows:assert r['status']==('PASS' if r['observed']==r['expected'] else 'FAIL')
 report['results'][stage]=dict(collections.Counter(r['status'] for r in rows))
assert report['results']=={'baseline':{'PASS':7,'FAIL':1},'fixed':{'PASS':206},'xml':{'PASS':8}}
trace=[json.loads(line) for line in (runtime/'mcp-trace.jsonl').read_text().splitlines()];names=collections.Counter(e['request']['params']['name'] for e in trace)
assert set(names)<={'get_document','get_control','get_log','set_mode','set_log_view','get_log_view','list_documents','find_controls','insert_log_marker','clear_log'}
report['mcp_call_names']=dict(names);report['mcp_response_errors']=[e for e in trace if 'error' in e['response'] or e['response'].get('result',{}).get('isError')]
assert not report['mcp_response_errors']
packets=[json.loads(line) for line in (runtime/'bridge-datagrams.jsonl').read_text().splitlines()];report['packet_counts']=dict(collections.Counter(p.get('direction',p.get('event')) for p in packets))
rx=[p['midi'] for p in packets if p.get('direction')=='RX'];assert rx==[[145,61,100],[129,61,0],[145,60,100]]
drops=[p for p in packets if p.get('direction')=='DROPPED'];assert len(drops)==1 and drops[0]['hex']=='2f6d6964690000002c6d000000003c81'
report['accepted_app_midi']=rx;report['dropped_off']=drops
for p in packets:
 if p.get('direction') in ['TX','RX']:
  b=bytes.fromhex(p['hex']);assert len(b)==16 and b[:12]==b'/midi\0\0\0,m\0\0' and [b[15],b[14],b[13]]==p['midi']
first_rx=next(i for i,p in enumerate(packets) if p.get('direction')=='RX');report['receive_only_prefix_app_rx']=sum(p.get('direction')=='RX' for p in packets[:first_rx]);assert report['receive_only_prefix_app_rx']==0
with tempfile.TemporaryDirectory(prefix='touchosc-review-') as d:
 p=pathlib.Path(d)/'new.xml'
 first=subprocess.run(['python3',str(scope/'pack.py'),'--output',str(p)],capture_output=True,text=True)
 assert first.returncode==0 and p.read_bytes()==xml.read_bytes()
 second=subprocess.run(['python3',str(scope/'pack.py'),'--output',str(p)],capture_output=True,text=True)
 assert second.returncode!=0 and 'FileExistsError' in second.stderr and p.read_bytes()==xml.read_bytes()
 report['cli_exclusive_output']={'first_exit':first.returncode,'second_exit':second.returncode,'existing_bytes_unchanged':True}
(evidence/'independent-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['source','hashes','mcp_response_errors']},indent=2));print('Independent closure verification: PASS')
