from pathlib import Path
import json, os, sys, time


def sample():
    result = {}
    for line in Path('/proc/stat').read_text().splitlines():
        name, *values = line.split()
        if name.startswith('cpu') and name[3:].isdigit() and int(name[3:]) in os.sched_getaffinity(0):
            result[int(name[3:])] = [int(v) for v in values[:8]]
    return result


start = sample()
time.sleep(int(sys.argv[1]))
end = sample()
rows = []
for cpu in start:
    delta = [a - b for a, b in zip(end[cpu], start[cpu])]
    total = sum(delta)
    rows.append({'cpu': cpu, 'total_ticks': total, 'idle_fraction': round(delta[3] / total, 4), 'steal_fraction': round(delta[7] / total, 4)})
print(json.dumps(sorted(rows, key=lambda x: (-x['idle_fraction'], x['steal_fraction'], x['cpu'])), indent=2))
