#!/usr/bin/env python3
import hashlib,json,subprocess
from pathlib import Path
root=(Path(__file__).resolve().parent/'../current-976').resolve()
qualification=json.loads((root/'docs/lanes/fwui/current/integration-qualification.json').read_text())
source=subprocess.check_output(['git','-C',root,'rev-parse','HEAD','HEAD^{tree}','HEAD:firmware'],text=True).splitlines(); assert source[0]=='2c16e15f4d3a6cc98f650b1eb8415899210182d1' and source[2]==qualification['stock']['firmware_tree']
output={'source':source[0],'tree':source[1],'firmware_tree':source[2],'cross_checked_pr':986,'models':{}}
for model,board in [('elite','smk37-elite'),('pro','smk37')]:
    ref=qualification['stock']['models'][model]
    paths={'elf':root/'build'/board/'x0x.elf','app':root/'build'/board/'x0x.bin','loader':root/'build'/board/'loader/ota.bin','package':root/'build'/('x0x-'+board+'.fwsc')}
    hashes={label:{'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for label,path in paths.items()}
    assert ref['binary_fingerprints']==hashes,(model,ref['binary_fingerprints'],hashes)
    log=(Path(__file__).parent/(model+'.log')).read_text()
    for marker,field in [('XIP free','xip_free'),('pool reserve','pool_reserve'),('pool raw free','pool_raw_free'),('pool margin','pool_margin')]:
        assert f"{marker}: {ref['memory_bytes'][field]} B" in log,(marker,model)
    assert 'smk package test passed' in (Path(__file__).parent/(model+'-package.log')).read_text()
    output['models'][model]={'outputs':hashes,'verified_stock_memory':ref['memory_bytes'],'package_test':'pass','match_PR986':True}
print(json.dumps(output,indent=2))
