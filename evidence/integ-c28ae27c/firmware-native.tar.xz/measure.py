#!/usr/bin/env python3
"""Measure the five verified owner zones against two actual linked stock applications."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('firmware', type=Path)
parser.add_argument('nightly', type=Path)
parser.add_argument('--source', required=True, help='Commit or tree used to build the models')
args = parser.parse_args()
fw = args.firmware.resolve()
assets = args.nightly.resolve() / 'web/product-site/assets/starting-breaks'
sys.path.insert(0, str(fw / 'tools'))
sys.path.insert(0, str(assets))
import break_pack
import fm1pkg_make
import verify_assets

fm1pkg_make.set_board('smk37')
code_max = fm1pkg_make.APP_CODE_MAX
reserve = 1024

def digest(data):
    return hashlib.sha256(data).hexdigest()

# Verify exact ADPCM, decoded PCM, and WAV for all five against their contract.
subprocess.run([sys.executable, str(assets / 'verify_assets.py')], check=True,
               stdout=subprocess.DEVNULL)
contract = verify_assets.load_contract(assets)
loops = [dict(name=asset['name'], nsamples=asset['frames'], bars=1,
              adpcm=(assets / (asset['id'] + '.adpcm')).read_bytes())
         for asset in contract['assets']]
rate = contract['rate']
bank = break_pack.encode_pack(loops, rate)
assert digest(bank) == '8df1316157fc8ce8dcb87cfd267fea83790702ccd1963ae91c0de60ca255b582'
assert break_pack.parse_pack(bank) == (rate, loops)
result = dict(source=args.source, code_max=code_max, reserve=reserve,
              asset_contract_sha256=verify_assets.CONTRACT_SHA256,
              verified_adpcm_pcm_wav=[a['id'] for a in contract['assets']],
              bank_bytes=len(bank), bank_sha256=digest(bank), models={})
with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    reader = td / 'brk_pack_test'
    subprocess.run(['cc', '-O2', '-Wall', '-I' + str(fw / 'firmware/src'), '-o', str(reader),
                    str(fw / 'tests/brk_pack_test.c')], check=True)
    def native_parse(image):
        imagefile = td / 'image.bin'
        imagefile.write_bytes(image)
        run = subprocess.run([str(reader), str(imagefile)], check=True, capture_output=True,
                             text=True)
        return run.stdout.strip()
    expected = '5 ' + ','.join(f"{r['name']} {r['nsamples']} 1 {len(r['adpcm'])}" for r in loops)
    # The full bank is accepted by the same reader in an empty, adequately sized app region.
    positive = break_pack.place_pack(b'\0' + b'\xff' * (code_max - 1), bank, code_max - reserve)
    result['native_full_bank_control'] = native_parse(positive)
    assert result['native_full_bank_control'] == expected
    for model, folder in [('elite', 'smk37-elite'), ('pro', 'smk37')]:
        app = (fw / 'build' / folder / 'x0x.bin').read_bytes()
        package = (fw / 'build' / ('x0x-' + folder + '.fwsc')).read_bytes()
        padded = app.ljust(code_max, b'\xff')
        assert len(padded) == code_max
        start = (len(app.rstrip(b'\xff')) + 15) & ~15
        usable = code_max - reserve - start
        fits = []
        trials = 0
        full_verdict = ''
        for count in range(1, len(loops) + 1):
            for subset in itertools.combinations(loops, count):
                pack = break_pack.encode_pack(subset, rate)
                trials += 1
                try:
                    placed = break_pack.place_pack(padded, pack, code_max - reserve)
                except ValueError as exc:
                    assert str(exc) == f'loop pack needs {len(pack)} bytes, {usable} free'
                    if count == len(loops):
                        full_verdict = str(exc)
                else:
                    assert placed[:len(app)] == app and placed[-reserve:] == padded[-reserve:]
                    fits.append([loop['name'] for loop in subset])
                    assert native_parse(placed).startswith(str(count) + ' ')
                    if count == len(loops):
                        full_verdict = 'PASS'
        # Probe the exact model boundary with a valid one-zone pack of precisely that size.
        assert usable >= 72
        control = dict(name='CONTROL', nsamples=2*(usable - 40), bars=1, adpcm=bytes(usable - 40))
        at_limit = break_pack.encode_pack([control], rate)
        assert len(at_limit) == usable
        placed = break_pack.place_pack(padded, at_limit, code_max - reserve)
        assert placed[:len(app)] == app and placed[-reserve:] == padded[-reserve:]
        accepted = native_parse(placed)
        assert accepted == f"1 CONTROL {control['nsamples']} 1 {len(control['adpcm'])}"
        control['nsamples'] += 2
        control['adpcm'] += b'\0'
        try:
            break_pack.place_pack(padded, break_pack.encode_pack([control], rate), code_max - reserve)
        except ValueError as exc:
            assert str(exc) == f'loop pack needs {usable + 1} bytes, {usable} free'
            oversized = str(exc)
        else:
            raise AssertionError('native packer admitted a pack past the reserved floor')
        result['models'][model] = dict(app_bytes=len(app), app_sha256=digest(app),
                                      package_sha256=digest(package), aligned_start=start,
                                      usable=usable, native_subsets_tried=trials,
                                      native_subsets_fit=fits, five_zone_verdict=full_verdict,
                                      shortfall=max(0, len(bank) - usable),
                                      at_capacity_native_reader=accepted, one_byte_over=oversized)
print(json.dumps(result, indent=2))
