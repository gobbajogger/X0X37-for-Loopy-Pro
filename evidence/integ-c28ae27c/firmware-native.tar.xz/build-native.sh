#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/../current-976"
proof=$(realpath ../current-proof)
export TMPDIR="$proof/tmp" JIELI_TOOLCHAIN="$(realpath ../../dependencies/jieli-linux-toolchains-20260730.1)" AC79_SDK="$(realpath ../sdk)" X0X_JOBS=1
for model in elite pro; do
    case "$model" in
        elite) board=smk37-elite; product='SMK-37 Elite_900';;
        pro) board=smk37; product='SMK-37 Pro_900';;
    esac
    echo "$(date -u +%FT%TZ) $model native start"
    MODEL="$model" ./build.sh > "$proof/$model.log" 2>&1
    python -B tests/smk_pkg_test.py "build/x0x-$board.fwsc" "$product" > "$proof/$model-package.log" 2>&1
    echo "$(date -u +%FT%TZ) $model native and package accepted"
done
