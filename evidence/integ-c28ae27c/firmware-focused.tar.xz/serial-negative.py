import importlib.util
from pathlib import Path
import sys
root = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location('admission',root/'tests/host/test_runner_admission.py')
admission = importlib.util.module_from_spec(spec)
spec.loader.exec_module(admission)
source = (root/'tests/run_tests.sh').read_text()
anchor = '[ "$PHASE" = W ] || wait'
assert source.count(anchor)==1
source = source.replace(anchor,'wait')
result = admission.execute(source, 2, 'install-slots-web fastmath')
assert result['rc'] == 1, result['trace']
assert 'install-slots-web never overlapped fastmath' in result['trace'],result['trace']
print('PASS serialized scheduler rejected: install-slots-web never overlapped fastmath; runner returned 1')
