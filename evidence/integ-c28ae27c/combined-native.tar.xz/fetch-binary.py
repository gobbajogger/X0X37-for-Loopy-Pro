from pathlib import Path
import base64, hashlib, json, os, sys, urllib.request
root=Path(__file__).resolve().parent
for model,oid in [('elite','e21fad9a16f89d46c50a56e95272689351ca74f4'),('pro','263a134391c127e25f0829324feb2a8a0793bfe7')]:
    url='https://api.github.com/repos/gobbajogger/DnBOX/git/blobs/'+oid
    req=urllib.request.Request(url,headers={'Accept':'application/vnd.github+json','User-Agent':'DnBOX-integration-qualification'})
    with urllib.request.urlopen(req,timeout=15) as reply: result=json.load(reply)
    data=base64.b64decode(''.join(result['content'].split()),validate=True)
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid==result['sha']
    assert len(data)==result['size']
    (root/(model+'-github-readback.fwsc')).write_bytes(data)
    print(model,oid,len(data),hashlib.sha256(data).hexdigest(),flush=True)
