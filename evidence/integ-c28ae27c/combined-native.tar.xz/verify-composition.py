from pathlib import Path
import json, subprocess
repo=Path(__file__).resolve().parents[1]/'native-current'; out=Path(__file__).resolve().parent
old='b5207372b5d342575b70b651b7dd413527c2f161'; integ='2c16e15f4d3a6cc98f650b1eb8415899210182d1'; sound='63278e3322aefa89b25f129ca2fccc35ef3b3b3d'; fwui='9dd6f2df020340f7a82ab241ef07c6ec16195ebc'; base='1c82772bac9a33f030bf954ec6151987aef2cbb8'; old_integ='bdef4bcab365d99d65cde22b10d3d607d1ad96ad'
def git(*args): return subprocess.check_output(['git','-C',str(repo),*args]);
def obj(ref):return git('rev-parse',ref).decode().strip()
def tree(ref):
    values={}
    for l in git('ls-tree','-r','-z',ref).split(b'\0'):
        if not l: continue
        hd,path=l.split(b'\t',1);mode,t,oid=hd.decode().split();assert t=='blob';values[path.decode()]=(mode,oid)
    return values
def changes(a,b): return {v.decode() for v in git('diff','--name-only','--no-renames','-z',a,b).split(b'\0') if v}
conflicts=git('diff','--name-only','--diff-filter=U').decode().splitlines();three=['docs/LIBRARY-INDEX.md','firmware/src/app/original_runtime.c','tests/host/break_retrigger_lut_test.c'];assert conflicts==three,conflicts
proof={}
for path in three[1:]:
    stages=[obj(':'+str(i)+':'+path) for i in range(1,4)]; expected=[obj(ref+':'+path) for ref in [base,fwui,sound]];assert stages==expected,(stages,expected);(repo/path).write_bytes(git('show',old+':'+path));proof[path]={'stages':stages,'resolved':obj(old+':'+path)}
path=three[0];common=git('show',base+':'+path); ours=git('show',integ+':'+path); theirs=git('show',sound+':'+path);older=git('show',old_integ+':'+path);old_combined=git('show',old+':'+path)
assert ours.startswith(older) and ours.startswith(common) and theirs.startswith(common) and old_combined==older+theirs[len(common):]; merged=ours+theirs[len(common):];(repo/path).write_bytes(merged);proof[path]={'stages':[obj(':'+str(i)+':'+path) for i in range(1,4)],'resolved':git('hash-object',path).decode().strip()}
git('add','--',*three);resolved=git('write-tree').decode().strip();previous=tree(old);current=tree(integ);expected=previous.copy();updates=changes(old_integ,'70d0cf6b')|changes('3e307cfa','46874497');assert path in updates
for update in updates:
  if update in current: expected[update]=current[update]
  else: del expected[update]
expected[path]=('100644',proof[path]['resolved']);observed=tree(resolved);different=[p for p in sorted(set(expected)|set(observed)) if expected.get(p)!=observed.get(p)];assert not different,different
input_dirs=['firmware','assets','ble','host','reference','tools','build.sh']; assert all(obj(f'{old}:{d}')==obj(f'{resolved}:{d}') for d in input_dirs)
receipt={'head':integ,'sound':sound,'fwui_already_in_head':fwui,'old':old,'tree':resolved,'expected_all_paths':len(expected),'expected_all_paths_match':True,'difference_from_old':sorted(changes(old,resolved)),'conflicts':proof,'build_inputs':{d:obj(f'{resolved}:{d}') for d in input_dirs}};(out/'composition.json').write_text(json.dumps(receipt,indent=2)+'\n');print(resolved,len(expected),len(receipt['difference_from_old']))
