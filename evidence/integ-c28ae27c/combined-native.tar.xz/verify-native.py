from pathlib import Path
import hashlib,json,re,struct,sys,subprocess
p=Path(__file__).resolve().parent
repo=p.parent/'native-current';old=json.loads((repo/'evidence/integ-b5207372/combined-builds.json').read_text());sys.path.insert(0,str(repo/'tools'));import fm1_install as unpack;import fm1pkg_make as encoder

def bytesig(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def git(*a):return subprocess.check_output(['git','-C',str(repo),*a],text=True).strip()
assert git('status','--porcelain')==''
source=git('show','-s','--format=%H %T %P','HEAD').split();assert source==['c28ae27c2c6a1afb70086c32a0ad321927e3dc25','a8ae61e48df54788e56a448b12413c71d0782d99','2c16e15f4d3a6cc98f650b1eb8415899210182d1','63278e3322aefa89b25f129ca2fccc35ef3b3b3d']
record={'source_commit':source[0],'source_tree':source[1],'parents':source[2:],'native_baseline':old['source_commit'],'sdk':{},'compiler_sha256':(p/'compiler.sha256').read_text().split()[0],'compiler_version':(p/'compiler.txt').read_text().splitlines()[0],'original_inputs':json.loads((p/'original-inputs.json').read_text())['ok'],'models':{}}
latest='2d9f05d6b7368b9e240d3b019934ebf9c1efc080'
assert git('rev-parse',latest+'^')==source[2]
changed=git('diff','--name-status','--no-renames',source[2],latest).splitlines()
assert changed==['M\tdocs/lanes/integ.md','A\tevidence/integ-cloud-3c6a5a04/cloud-run-checkpoint.json']
build_paths=['build.sh','firmware','ble','experiments','assets','tools','reference','host']
fixed={path:git('rev-parse',source[0]+':'+path) for path in build_paths}
for path,oid in fixed.items(): assert oid==git('rev-parse',old['source_commit']+':'+path)
latest_inputs={path:git('rev-parse',latest+':'+path) for path in build_paths}
for path,oid in latest_inputs.items(): assert oid==git('rev-parse',source[2]+':'+path)
record['combined_build_inputs_match_prior']=fixed
record['later_integration_head_check']={'before':source[2],'after':latest,'after_tree':git('rev-parse',latest+'^{tree}'),'changed_paths':changed,'matching_integration_inputs':latest_inputs,'unchanged_sound_parent':source[3]}
import build
sdk=p.parents[1]/'breakpack/sdk/cpu/wl82/tools'
for name,expected in build.SDK_SHA256.items():
    sig=bytesig((sdk/name).read_bytes());assert sig['sha256']==expected;record['sdk'][name]=sig
checksums=[]
for model,board,product in [('elite','smk37-elite','SMK-37 Elite_900'),('pro','smk37','SMK-37 Pro_900')]:
    dir=repo/'build'/board
    pkg=repo/'build'/('x0x-'+board+'.fwsc');app=dir/'x0x.bin';elf=dir/'x0x.elf';loader=dir/'loader/ota.bin';paths=[app,elf,loader,pkg]
    data={v.name:bytesig(v.read_bytes()) for v in paths}; previous=old['models'][model]; assert data==previous['outputs'],(model,data,previous['outputs']);raw=pkg.read_bytes();remote=(p/(model+'-github-readback.fwsc')).read_bytes();assert raw==remote
    image,blocks=unpack.deinterleave(raw);assert blocks==20 and unpack.product_of(raw)==product and not unpack.package_damage(image)
    entries={}
    for i in range(2):
        entry=unpack._dec(image[0x40+i*0x50:0x90+i*0x50]); offset,size=struct.unpack_from('<II',entry,8); name=entry[0x40:0x50].split(b'\0')[0].decode();entries[name]=image[offset:offset+size]
    assert entries['ota.bin']==loader.read_bytes(); area=bytearray(entries['flash.bin'][0x4000:]);encoder.sfc(area,0,len(area),0,encoder.KEY);entry=area[32:64];assert bytes(entry[16:24])==b'app.bin\0';app_offset,app_slot=struct.unpack_from('<II',entry,4);expected_bytes=app.read_bytes();assert bytes(area[app_offset:app_offset+len(expected_bytes)])==expected_bytes and app_slot>=len(expected_bytes)
    log=(p/(model+'-build.log')).read_text();numeric={field:int(re.search('^'+mark+r': (\d+) B$',log,re.M)[1]) for field,mark in [('xip_free','XIP free'),('pool_margin','pool margin'),('pool_reserve','pool reserve'),('pool_raw_free','pool raw free')]};assert numeric['xip_free']==previous['xip_free'] and numeric['pool_margin']==previous['pool_margin'] and numeric['pool_reserve']==8192
    assert 'smk package test passed' in (p/(model+'-package.log')).read_text()
    for path in paths: checksums.append(data[path.name]['sha256']+'  '+str(path.relative_to(repo)))
    record['models'][model]={'command':'MODEL='+model+' ./build.sh','product':product,'native_build_exit':0,'package_test_exit':0,'outputs':data,'stock_memory_bytes':numeric,'readback':{'github_package_identical':True,'github_blob_id':git('hash-object',str(pkg)),'app_identical':True,'ota_identical':True,'logical_blocks':blocks},'all_four_outputs_match_prior':True,'started_utc':(p/(model+'.started')).read_text().strip(),'finished_utc':(p/(model+'.finished')).read_text().strip()}
(p/'SHA256SUMS').write_text('\n'.join(checksums)+'\n');(p/'native-builds.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:{'memory':v['stock_memory_bytes'],'package':v['outputs'][('x0x-smk37-elite.fwsc' if k=='elite' else 'x0x-smk37.fwsc')]} for k,v in record['models'].items()}))
