#!/bin/bash
set -euo pipefail
jobroot=$(cd "$(dirname "$0")/../.." && pwd)
evidence=$jobroot/timing/native-proof
repo=$jobroot/timing/native-current
export JIELI_TOOLCHAIN=$jobroot/dependencies/jieli-linux-toolchains-20260730.1
export AC79_SDK=$jobroot/breakpack/sdk
export TMPDIR=$evidence/tmp
export X0X_JOBS=1
mkdir -p "$TMPDIR"
cd "$repo"
test "$(git rev-parse HEAD)" = c28ae27c2c6a1afb70086c32a0ad321927e3dc25
test -z "$(git status --porcelain)"
python3 tools/check_original_inputs.py --json > "$evidence/original-inputs.json"
"$JIELI_TOOLCHAIN/pi32v2/bin/clang" --version > "$evidence/compiler.txt"
sha256sum "$JIELI_TOOLCHAIN/pi32v2/bin/clang" > "$evidence/compiler.sha256"
for model in elite pro; do
    date -u +%FT%TZ > "$evidence/$model.started"
    MODEL="$model" ./build.sh > "$evidence/$model-build.log" 2>&1
    if [[ $model == elite ]]; then
        pkg=build/x0x-smk37-elite.fwsc
        product='SMK-37 Elite_900'
    else
        pkg=build/x0x-smk37.fwsc
        product='SMK-37 Pro_900'
    fi
    python3 tests/smk_pkg_test.py "$pkg" "$product" > "$evidence/$model-package.log"
    date -u +%FT%TZ > "$evidence/$model.finished"
done
