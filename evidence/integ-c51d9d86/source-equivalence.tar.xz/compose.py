from pathlib import Path
import json,os,subprocess
p=Path(__file__).resolve().parent;repo=p.parents[1]/'firmware';doc='docs/LIBRARY-INDEX.md';old='c51d9d8647fb72ae0628af6fef7fb8cfbcbd40e9';integ='711df7b3c416ddea7649242fc9a328ce974599f8';sound='2fe5930c161a30c907a4b91991ab3c9724380b10';oldinteg='be696332ec3f97a0914d485d2dbbd4998b929a25';oldsound='5837c73f754a667c526edd420aefbe7cf3a071bf'
def git(*argv,env=None):return subprocess.check_output(['git','-C',str(repo),*argv],env=env).decode().strip()
def tree(ref):
   out={}
   for line in git('ls-tree','-r',ref).splitlines():
      hdr,path=line.split('\t');mode,t,oid=hdr.split();assert t=='blob';out[path]=(mode,oid)
   return out
assert git('rev-parse',integ+'^')==oldinteg and git('rev-parse',sound+'^')==oldsound
lines=(p/'merge-tree.log').read_text().splitlines();merged=lines[0];assert [l for l in lines if l.startswith('CONFLICT')]==['CONFLICT (content): Merge conflict in '+doc]; base=git('merge-base',integ,sound);assert [l.split()[1] for l in lines[1:4]]==[git('rev-parse',r+':'+doc) for r in (base,integ,sound)];assert all(git('rev-parse',r+':'+doc)==git('rev-parse',prior+':'+doc) for r,prior in [(integ,oldinteg),(sound,oldsound)]); env={**os.environ,'GIT_INDEX_FILE':str(p/'composition.index')};git('read-tree',merged,env=env);git('update-index','--cacheinfo','100644,'+git('rev-parse',old+':'+doc)+','+doc,env=env);resolved=git('write-tree',env=env)
oldtree,a,b,result=map(tree,[old,integ,sound,resolved]);expected=oldtree.copy();updated={};groups={}
for prior,new,head in [(oldinteg,integ,a),(oldsound,sound,b)]:
 paths=git('diff','--name-only','--no-renames',prior,new).splitlines();groups[new]=paths
 for path in paths:
  assert path not in updated and path in head
  expected[path]=updated[path]=head[path]
assert expected==result and result.keys()==a.keys()|b.keys();assert len(updated)==21
roots=['build.sh','firmware','host','tests','tools','assets','ble','reference','experiments/original_synth','experiments/wobble','experiments/sound-hardware-v1/synthone-widen'];sameroots={k:git('rev-parse',old+':'+k) for k in roots};assert all(git('rev-parse',resolved+':'+k)==v for k,v in sameroots.items()); data={'parents':[integ,sound],'prior':old,'tree':resolved,'merge_base':base,'parent_counts':[len(a),len(b)],'total_paths':len(result),'zero_missing_parent_paths':True,'all_paths_match_prior_plus_exact_21_updates':True,'changed_by_parent':groups,'whole_root_identities':sameroots,'experiments_old_to_new':[git('rev-parse',ref+':experiments') for ref in [old,resolved]],'library_index_resolution':git('rev-parse',resolved+':'+doc)};(p/'source.json').write_text(json.dumps(data,indent=2)+'\n');(p/'tree-entries.json').write_text(json.dumps([dict(path=k,mode=m,type='blob',sha=o) for k,(m,o) in updated.items()]));print(resolved,len(result),len(updated))
