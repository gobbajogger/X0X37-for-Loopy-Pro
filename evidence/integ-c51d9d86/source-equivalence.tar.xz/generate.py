from pathlib import Path
import hashlib, json, os, sys
p=Path(__file__).resolve().parent;root=p.parent/'equivalence-source';sys.path.insert(0,str(root/'tools'));os.chdir(root);os.environ['X0X_GEN_CACHE']='0'
import build
build.BOARD='smk37';build.MODEL='elite';build.generate()
old=p.parent/'native-current'; files={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/'build/gen').glob('*.h')};assert len(files)==5 and files=={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (old/'build/gen').glob('*.h')}
(p/'generated.json').write_text(json.dumps(files,indent=2)+'\n');print('All five rebuilt headers match c51.')
