from pathlib import Path
import hashlib,json,re,subprocess,sys
p=Path(__file__).resolve().parent; root=p.parent/'equivalence-source'; oldroot=p.parent/'native-current'; runner=p.parent/'c51d9d86'; source=json.loads((p/'source.json').read_text()); new='3571c7dc29722356e486701fbe566da13cd36f04'; old=source['prior']; gitroot=oldroot

def git(*args):return subprocess.check_output(['git','-C',gitroot,*args]).decode().strip()
def blobs(ref):
 out={}
 for line in git('ls-tree','-r',ref).splitlines():
  hdr,path=line.split('\t');mode,typ,oid=hdr.split();out[path]=(mode,oid)
 return out

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
a,b=blobs(old),blobs(new);args=json.loads((runner/'compile-command.json').read_text());sr=Path(args['cwd']).resolve(); production={}; external={};generated={}; native={}
for item in args['args']:
 if not item.endswith('.c'):continue
 fp=(sr/item).resolve()
 if fp.is_relative_to(sr):
  key=fp.relative_to(sr).as_posix();assert a[key]==b[key];production[key]=b[key][1]
 else:external[str(fp.relative_to(runner))]=sha(fp)
host_headers={}
for line in (runner/'first/build.log').read_text().splitlines():
 match=re.match(r'^\.+ (.+?)$',line)
 if not match:continue
 fp=(sr/match[1]).resolve()
 if fp.is_relative_to(sr):
  key=fp.relative_to(sr).as_posix();assert a[key]==b[key];host_headers[key]=b[key][1]
 elif fp.is_relative_to(runner):generated[fp.relative_to(runner).as_posix()]=sha(fp)
root_sigs={}
for prefix in source['whole_root_identities']:
 ref=source['whole_root_identities'][prefix];assert git('rev-parse',new+':'+prefix)==ref;root_sigs[prefix]=ref
# The build plan is obtained from the stock builder. Stop at its compile dispatch, before any compiler is invoked.
sys.path.insert(0,str(oldroot/'tools'));import build
class PlanCaptured(Exception):pass
for model in ('elite','pro'):
 build.BOARD='smk37'; build.MODEL=model;build.BOARD_DEFS['smk37']=['-DBOARD_SMK37=1']+(['-DSMK_MODEL="SMK-37 Elite"'] if model=='elite' else []);build.OUT=p/'plan'/model;build.LDR=build.OUT/'loader';commands=[]
 def capture(*args):
  commands.extend(args);raise PlanCaptured
 build.tc_all=capture
 for entry in (build.build_loader,build.build_app):
  try:entry();raise AssertionError('no compile plan')
  except PlanCaptured:pass
 for cmd in commands:
  path=(oldroot/cmd[cmd.index('-c')+1]).resolve().relative_to(oldroot).as_posix();assert a[path]==b[path];native[path]=b[path][1]
# Verify project source references into the comparison tree under the production roots, including optional code.
query=subprocess.run(['git','-C',str(gitroot),'grep','-n','-E',r'^[[:space:]]*#[[:space:]]*include.*(sound-hardware-v1|original-bank-planner|integrated-sound)',new,'--','firmware','host','ble','experiments/original_synth','experiments/wobble'],text=True,capture_output=True);assert query.returncode in (0,1);includes=query.stdout.strip().splitlines();
assert includes, 'expected at least the guarded synthone-widen source reference'
for line in includes:assert 'synthone-widen/widen.h' in line,line
for name in ['first/run','second/run','first/bank-stress.c','first/bank-stress.patch','first/run-matrix.py','second/run-matrix.py','personal-br1-zone1.wav','compile-command.json']:external[name]=sha(runner/name)
for l in (runner/'identities.txt').read_text().splitlines()[2:]:
 expected,name=l.split(None,1);assert sha(runner/name)==expected
sums=(p.parent/'latest-proof/SHA256SUMS').read_text().splitlines();oldout={}
for l in sums:
 expected,name=l.split(None,1);assert sha(oldroot/name)==expected;oldout[name]=expected
assert len(native)>70 and len(production)>=69 and len(host_headers)>100
summary={'source_commit':new,'prior_measured_source':old,'stock_planned_compile_units_both_models':len(native),'stock_planned_units':native,'direct_comparison_tree_includes':includes,'unchanged_source_roots':root_sigs,'host_stress_production_translation_units':production,'host_stress_reached_repo_includes':host_headers,'unchanged_external_harness_and_stimulus_sha256':external,'host_stress_generated_inputs_sha256':generated,'c51_native_outputs_rehashed':oldout,'prior_native_raw_receipt_sha256':sha(p.parent/'c51d9d86-native-receipt.tar.xz')};(p/'input-equivalence.json').write_text(json.dumps(summary,indent=2)+'\n');print('native translation units',len(native),'host production units',len(production),'host repo includes',len(host_headers),'comparison-tree direct includes',includes)
