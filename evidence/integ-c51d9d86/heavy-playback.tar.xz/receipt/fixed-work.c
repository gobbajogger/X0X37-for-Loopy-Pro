#define _POSIX_C_SOURCE 200809L
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
static int64_t stamp(clockid_t c) {struct timespec t; if(clock_gettime(c,&t)) exit(2); return (int64_t)t.tv_sec*1000000000+t.tv_nsec;}
static int order(const void *a,const void *b) {int64_t x=*(const int64_t*)a,y=*(const int64_t*)b; return (x>y)-(x<y);}
int main(int argc,char **argv) {
 if(argc!=3)return 2;
 int blocks=atoi(argv[1]), iterations=atoi(argv[2]);
 if(blocks<1||iterations<1)return 2;
 uint64_t state=1; int misses=0; int64_t *times=calloc(blocks,sizeof(*times));
 if(!times)return 2;
 for(int i=0;i<blocks;i++) {
  int64_t w=stamp(CLOCK_MONOTONIC),c=stamp(CLOCK_THREAD_CPUTIME_ID);
  for(int j=0;j<iterations;j++) state=state*UINT64_C(6364136223846793005)+1;
  times[i]=stamp(CLOCK_THREAD_CPUTIME_ID)-c; w=stamp(CLOCK_MONOTONIC)-w;
  if(times[i]>11609000){printf("miss %d %" PRId64 " %" PRId64 "\n",i,times[i],w);misses++;}
 }
 qsort(times,blocks,sizeof(*times),order);
 printf("blocks=%d iterations=%d median_ns=%" PRId64 " p99_ns=%" PRId64 " max_ns=%" PRId64 " misses=%d state=%" PRIu64 "\n",blocks,iterations,times[blocks/2],times[(blocks-1)*99/100],times[blocks-1],misses,state);
 free(times); return 0;
}
