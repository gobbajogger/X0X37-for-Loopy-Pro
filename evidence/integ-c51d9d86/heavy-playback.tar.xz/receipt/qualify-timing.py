import json
import re
from pathlib import Path

def records(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]

def key(row):
    return row["sweep"], *row["banks"]

def metric(row, name):
    return float(re.search(r"\b"+name+r"=([\d.]+)",row["stderr"])[1])

def summarize(rows):
    assert len(rows) == len({key(row) for row in rows}) == 32
    for row in rows:
        assert row["blocks"]==1024 and row["status"]==0
        assert "audible=31 drum_masks=2047/2047" in row["stderr"] and "packets=131072" in row["stderr"]
        assert row["traces"]["audio.i32"][0] == 4194304
    return {"blocks":sum(row["blocks"] for row in rows),
            "cpu_misses":int(sum(metric(r,"CPU_misses") for r in rows)),
            "wall_misses":int(sum(metric(r,"wall_misses") for r in rows)),
            "worst_cpu_us":max(metric(r,"CPU_peak_us") for r in rows),
            "worst_wall_us":max(metric(r,"wall_peak_us") for r in rows),
            "cpu_miss_cases":[{"sweep":r["sweep"],"banks":r["banks"],"misses":int(metric(r,"CPU_misses")),"peak_us":metric(r,"CPU_peak_us")} for r in rows if metric(r,"CPU_misses")]}

def trace_map(rows):
    return {key(r):r["traces"] for r in rows}

if __name__=="__main__":
    import sys
    groups=[records(p) for p in sys.argv[1:]]
    result=[summarize(rows) for rows in groups]
    baseline=trace_map(groups[0])
    same=[sum(row["traces"]==baseline[key(row)] for row in group) for group in groups]
    print(json.dumps({"runs":result,"matches_first_run_both_traces":same},indent=2))
