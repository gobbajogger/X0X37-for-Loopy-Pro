#!/bin/bash
set -euo pipefail
run=$1
cpu=$2
for name in first second; do
    taskset -c "$cpu" python3 "$run/$name/run-matrix.py" 1024 matrix > "$run/$name/matrix.log" 2>&1
done
taskset -c "$cpu" python3 "$run/first/run-matrix.py" 1024 negative > "$run/first/negative.log" 2>&1
python3 timing/summarize_new.py "$run" > "$run/summary.json"
