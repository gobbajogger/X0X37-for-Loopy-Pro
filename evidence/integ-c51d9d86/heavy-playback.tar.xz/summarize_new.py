from pathlib import Path
import importlib.util
import json
import re
import sys

here = Path(__file__).resolve().parent
run = Path(sys.argv[1]).resolve()
module = importlib.util.spec_from_file_location('timing_qualification', here / 'receipt/qualify-timing.py')
qualification = importlib.util.module_from_spec(module)
module.loader.exec_module(qualification)
raw = [qualification.records(run / case / 'matrix.jsonl') for case in ('first', 'second')]
reference = qualification.records(here / 'receipt/current1/matrix.jsonl')
first_traces = qualification.trace_map(raw[0])
old_traces = qualification.trace_map(reference)
summary = {'revision_and_tree': (run / 'identities.txt').read_text().splitlines()[0], 'deadline_us': 11609, 'runs': []}
for rows in raw:
    result = qualification.summarize(rows)
    metrics = [json.loads(row['stdout']) for row in rows]
    result['maximum_case_p99_cpu_us'] = max(m['p99_ns'] for m in metrics) / 1000
    result['maximum_case_median_cpu_us'] = max(m['median_ns'] for m in metrics) / 1000
    result['pcm_and_meter_matching_first'] = sum(row['traces'] == first_traces[qualification.key(row)] for row in rows)
    result['prior_composition'] = {name: sum(row['traces'][name] == old_traces[qualification.key(row)][name] for row in rows) for name in ('audio.i32', 'peak-scope.bin')}
    summary['runs'].append(result)
negative = qualification.records(run / 'first/negative.jsonl')[0]
assert negative['status'] == 3 and 'audible=23' in negative['stderr']
summary['mute_b_control'] = {'exit': negative['status'], 'diagnostic': negative['stderr']}
summary['fixed_work_controls'] = {path.stem: path.read_text().splitlines()[-1] for path in here.glob('qualify-cpu*.log') if path.stat().st_size and 'blocks=' in path.read_text().splitlines()[-1]}
print(json.dumps(summary, indent=2))
