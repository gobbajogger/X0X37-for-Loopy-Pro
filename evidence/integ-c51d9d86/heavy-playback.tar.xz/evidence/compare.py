"""Compare the complete two runs with the most recently built playback baseline."""
import hashlib
import json
from pathlib import Path
import sys


def rows(path):
    result = {}
    for line in path.read_text().splitlines():
        entry = json.loads(line)
        key = (entry['sweep'], *entry['banks'])
        assert key not in result
        assert entry['status'] == 0 and entry['blocks'] == 1024
        assert set(entry['traces']) == {'audio.i32', 'peak-scope.bin'}
        result[key] = entry['traces']
    assert set(result) == {(s, a, b) for s in (1, 2) for a in range(4) for b in range(4)}
    return result


baseline, candidate = map(Path, sys.argv[1:3])
before = rows(baseline / 'first/matrix.jsonl')
after = rows(candidate / 'first/matrix.jsonl')
repeat = rows(candidate / 'second/matrix.jsonl')
variants = ('audio.i32', 'peak-scope.bin')
case_changes = []
for (sweep, a, b), traces in sorted(after.items()):
    key = sweep, a, b
    case_changes.append({'sweep': sweep, 'banks': [a, b],
                         'changed_from_previous': [k for k in variants if traces[k] != before[key][k]],
                         'repeat_difference': [k for k in variants if traces[k] != repeat[key][k]]})
headers = {}
for name in ('felucca_font.h', 'x0x_break_bank.h', 'x0x_drum_samples.h', 'x0x_drum_tables.h'):
    hashes = [hashlib.sha256((loc / 'generated' / name).read_bytes()).hexdigest() for loc in (baseline, candidate)]
    headers[name] = {'previous': hashes[0], 'candidate': hashes[1], 'changed': hashes[0] != hashes[1]}
print(json.dumps({'previous': baseline.name, 'candidate': candidate.name,
                  'previous_matches': {n: sum(n not in row['changed_from_previous'] for row in case_changes) for n in variants},
                  'repeat_matches': {n: sum(n not in row['repeat_difference'] for row in case_changes) for n in variants},
                  'generated_header_sha256': headers, 'cases': case_changes}, indent=2))
