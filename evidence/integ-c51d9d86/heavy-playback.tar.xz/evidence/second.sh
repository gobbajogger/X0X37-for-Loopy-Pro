#!/bin/bash
set -euo pipefail
proof=$(realpath "$(dirname "$0")")
cd "$proof/../.."
run=timing/c51d9d86
cpu=4
export TMPDIR="$proof/tmp" PYTHONDONTWRITEBYTECODE=1
record() {
    date -u +%FT%TZ
    cat /proc/loadavg
    taskset -c "$cpu" bash -c 'taskset -pc $$'
}
record > "$proof/control-start.txt"
taskset -c "$cpu" timing/fixed-work 32768 850000 > "$proof/control.log"
record > "$proof/control-finished.txt"
grep -Eq '^blocks=32768 iterations=850000 .*state=17005455421937811457$' "$proof/control.log"
record > "$proof/second-start.txt"
taskset -c "$cpu" python3 "$run/second/run-matrix.py" 1024 matrix > "$run/second/matrix.log" 2>&1
record > "$proof/second-finished.txt"
python3 timing/summarize_new.py "$run" > "$run/summary.json"
python3 "$proof/compare.py" timing/05722a88 "$run" > "$proof/trace-comparison.json"
