#!/bin/bash
set -euo pipefail
proof=$(realpath "$(dirname "$0")")
cd "$proof/../.."
run=timing/c51d9d86
cpu=4
export PYTHONDONTWRITEBYTECODE=1 TMPDIR="$proof/tmp"
record() {
    date -u +%FT%TZ
    cat /proc/loadavg
    taskset -c "$cpu" bash -c 'taskset -pc $$'
}
record > "$proof/quiet-start.txt"
taskset -c "$cpu" timing/fixed-work 32768 850000 > "$proof/quiet-control.log"
record > "$proof/quiet-finished.txt"
grep -Eq '^blocks=32768 iterations=850000 .*state=17005455421937811457$' "$proof/quiet-control.log"
if grep -q ' misses=0 state=' "$proof/quiet-control.log"; then
    mkdir "$run/third"
    cp "$run/second/run" "$run/second/run-matrix.py" "$run/third/"
    record > "$proof/third-start.txt"
    taskset -c "$cpu" python3 "$run/third/run-matrix.py" 1024 matrix > "$run/third/matrix.log" 2>&1
    record > "$proof/third-finished.txt"
    python3 timing/receipt/qualify-timing.py "$run/first/matrix.jsonl" "$run/third/matrix.jsonl" > "$proof/third-summary.json"
fi
