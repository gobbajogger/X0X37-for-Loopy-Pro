from pathlib import Path
import os, shlex, subprocess
w=Path(__file__).resolve().parent
repo=Path('/workspace/scratch/1a3b8de346b2/breakpack/sound-c51')
path=repo/'tests/host/audio_path_stress.c'
s=path.read_text()
def replace(old,new):
    global s
    assert s.count(old)==1,old
    s=s.replace(old,new)
replace('if (argc != 7) return 2;', '''if (argc != 9) return 2;
    int bank_a=atoi(argv[7]), bank_b=atoi(argv[8]);
    assert(bank_a>=0 && bank_a<4 && bank_b>=0 && bank_b<4);''')
replace('engine_bass_select_preset(0, FACTORY_BANK_CHICAGO, chicago','engine_bass_select_preset(0, bank_a, chicago')
replace('engine_bass_select_preset(1, FACTORY_BANK_MIAMI, miami','engine_bass_select_preset(1, bank_b, miami')
replace('assert(engine_bass_bank(0) == FACTORY_BANK_CHICAGO);','assert(engine_bass_bank(0) == bank_a);')
replace('assert(engine_bass_bank(1) == FACTORY_BANK_MIAMI);','assert(engine_bass_bank(1) == bank_b);')
replace('double total = 0, peak = 0, foreground_peak = 0;', '''double total = 0, peak = 0, foreground_peak = 0;
    double wall_peak=0;
    unsigned late_wall=0, late_cpu=0, audible_parts=0, drum_masks[2]={0,0};
    unsigned negative=getenv("INTEG_NEGATIVE_SILENT_B")!=NULL;
    if (negative) {
        for (int s=0;s<16;s++) proj.pat[0].bass[1].step[s].flags=0;
        engine_bass_off(1);
    }
    for(unsigned part=0;part<NPARTS;part++) eng_peak[part]=0;
    struct timespec tick;
    clock_gettime(CLOCK_MONOTONIC, &tick);''')
replace('double elapsed = 0;', '''double elapsed = 0, wall_elapsed = 0;
        unsigned read_start=mi_r;''')
replace('double t0 = stress_ns();', '''clock_gettime(CLOCK_MONOTONIC,&tick);
            double wall_start=tick.tv_sec*1e9+tick.tv_nsec;
            double t0 = stress_ns();''')
replace('elapsed += stress_ns() - t0;', '''elapsed += stress_ns() - t0;
            clock_gettime(CLOCK_MONOTONIC,&tick);
            wall_elapsed+=tick.tv_sec*1e9+tick.tv_nsec-wall_start;''')
replace('total += elapsed;', '''assert(mi_r-read_start==128);
        assert(engine_bass_bank(0)==bank_a && engine_bass_bank(1)==bank_b);
        if (wall_elapsed>wall_peak) wall_peak=wall_elapsed;
        late_wall += wall_elapsed>11609000.0;
        late_cpu += elapsed>11609000.0;
        for(unsigned kit=0;kit<2;kit++) for(unsigned v=0;v<NDRUM;v++)
            if(eng_hit[kit][v]) drum_masks[kit]|=1u<<v;
        total += elapsed;''')
replace('uint16_t value = eng_peak[p];','uint16_t value = eng_peak[p];\n            if(value) audible_parts|=1u<<p;')
replace('0x80u | (2u + b)', '0x80u | (2u + (negative && b==1 ? 0u : b))')
replace('0x90u | (2u + b)', '0x90u | (2u + (negative && b==1 ? 0u : b))')
replace('A=Chicago, B=Miami, at the profile', 'Select the requested banks, using the profile')
replace('assert(blits > blits0);','''assert(blits > blits0);
    fprintf(stderr,"banks=%d/%d blocks=%d audible=%u drum_masks=%u/%u CPU_peak_us=%.3f wall_peak_us=%.3f CPU_misses=%u wall_misses=%u packets=%u redraws=%u\\n",
      bank_a,bank_b,blocks,audible_parts,drum_masks[0],drum_masks[1],peak/1000.,wall_peak/1000.,late_cpu,late_wall,128u*blocks,blits-blits0);
    if (audible_parts!=((1u<<NPARTS)-1) || drum_masks[0]!=((1u<<NDRUM)-1) || drum_masks[1]!=((1u<<NDRUM)-1)) return 3;''')
out=w/'bank-stress.c';out.write_text(s)
(w/'bank-stress.patch').write_text(subprocess.run(['diff','-u','--label','tests/host/audio_path_stress.c','--label','diagnostic/bank-stress.c',str(path),str(out)],capture_output=True,text=True).stdout)
setup=subprocess.check_output(['sh','-c','. tests/host/original_build.sh; printf "%s\\n" "$ORIGINAL_FLAGS" "$ORIGINAL_SOURCES"'],cwd=repo,text=True).splitlines()
flags,sources=map(shlex.split,setup)
cmd=['cc','-H','-O2','-ffp-contract=off','-std=c99','-Wno-unused-function','-Wno-unused-parameter','-DX0X_HOST','-iquote',str(repo/'firmware/src/dsp'),'-iquote',str(repo/'tests/host'),*flags,'-Ifirmware/src','-Ifirmware/src/app','-Ifirmware/src/dsp','-I/workspace/scratch/1a3b8de346b2/timing/c51d9d86/generated',str(out),*sources,'-lm','-o',str(w/'run')]
with (w/'build.log').open('w') as output:
    subprocess.run(cmd,cwd=repo,stdout=output,stderr=subprocess.STDOUT,check=True)
