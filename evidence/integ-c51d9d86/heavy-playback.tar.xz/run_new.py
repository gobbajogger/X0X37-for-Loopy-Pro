from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys

here = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
ref = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
root = here / ref[:8]
root.mkdir(exist_ok=True)
generated = root / 'generated'
generated.mkdir(exist_ok=True)
for name in ('gen_font.py', 'gen_drum_samples.py'):
    target = 'felucca_font.h' if name == 'gen_font.py' else 'x0x_drum_samples.h'
    subprocess.run([sys.executable, repo / 'tools' / name, generated / target], cwd=repo, check=True)
sys.path.insert(0, str(repo / 'tools'))
import break_pack
break_pack.write_empty_header(generated / 'x0x_break_bank.h')
assert (generated / 'x0x_break_bank.h').read_bytes() == (here / 'receipt/current-gen/x0x_break_bank.h').read_bytes()
subprocess.run([sys.executable, 'tools/check_original_inputs.py'], cwd=repo, check=True)
archive = here / 'receipt/current1'
for name in ('first', 'second'):
    (root / name).mkdir(exist_ok=True)
shutil.copy2(here / 'personal-br1-zone1.wav', root / 'personal-br1-zone1.wav')
old = '/workspace/scratch/e28373b2e7b3/i3/latest'
prepare = (archive / 'prepare.py').read_text().replace(old, str(repo)).replace('/workspace/scratch/e28373b2e7b3/i3/current-gen', str(generated))
# Build the unchanged driver from the PR archive. All path substitutions above are local workspace locations.
(root / 'first/prepare.py').write_text(prepare)
with (root / 'build.stdout').open('w') as log:
    subprocess.run([sys.executable, root / 'first/prepare.py'], check=True, stdout=log, stderr=subprocess.STDOUT)
assert (root / 'first/bank-stress.patch').read_bytes() == (archive / 'bank-stress.patch').read_bytes()
assert str(generated / 'x0x_break_bank.h') in (root / 'first/build.log').read_text()
shutil.copy2(root / 'first/run', root / 'second/run')
for name in ('first', 'second'):
    (root / name / 'run-matrix.py').write_text((archive / 'run-matrix.py').read_text().replace(old, str(repo)))
(root / 'identities.txt').write_text(subprocess.check_output(['git', 'show', '-s', '--format=%H %T %P', 'HEAD'], cwd=repo, text=True) + subprocess.check_output(['cc', '--version'], text=True).splitlines()[0] + chr(10) + subprocess.check_output(['sha256sum', 'first/run', 'second/run', 'first/bank-stress.patch', 'generated/x0x_break_bank.h', 'personal-br1-zone1.wav'], cwd=root, text=True))
print(root, flush=True)
