#!/usr/bin/env python3
"""Estimate stock XIP consumed by byte-identical, attributed native function bodies."""
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

build = Path(sys.argv[1])
result = {}
for model, board in [('elite', 'smk37-elite'), ('pro', 'smk37')]:
    elf = build / board / 'x0x.elf'
    image = (build / board / 'text.bin').read_bytes()
    sections = subprocess.check_output(['readelf', '-SW', elf], text=True)
    text_section = re.search(r'\[\s*(\d+)\]\s+\.text\s+PROGBITS\s+([0-9a-f]+)\s+[0-9a-f]+\s+([0-9a-f]+)', sections)
    section, vma, length = text_section.groups()
    assert len(image) == int(length, 16)
    base = int(vma, 16)
    symbols = subprocess.check_output(['readelf', '-sW', elf], text=True)
    spans = set()
    for line in symbols.splitlines():
        fields = line.split(None, 7)
        if len(fields) == 8 and fields[3] == 'FUNC' and fields[6] == section:
            start, size = int(fields[1], 16) - base, int(fields[2])
            if size:
                assert 0 <= start < start + size <= len(image)
                spans.add((start, start + size))
    sorted_spans = sorted(spans)
    assert all(b <= c for (_, b), (c, _) in zip(sorted_spans, sorted_spans[1:]))
    bodies = collections.Counter(image[start:end] for start, end in spans)
    duplicates = {body: copies for body, copies in bodies.items() if copies > 1}
    result[model] = dict(elf_sha256=hashlib.sha256(elf.read_bytes()).hexdigest(),
                         function_bodies=len(spans), function_bytes=sum(e-s for s,e in spans),
                         duplicate_groups=len(duplicates),
                         identical_bytes_after_first_copy=sum(len(b)*(n-1) for b,n in duplicates.items()))
print(json.dumps(result, indent=2))
