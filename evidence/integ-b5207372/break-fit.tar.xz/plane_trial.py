#!/usr/bin/env python3
"""Lossless storage-only experiment for the owner's entire ADPCM bank."""
import hashlib
import json
import lzma
import sys
from pathlib import Path
import numpy as np

sources = Path(sys.argv[1]).resolve()
assets = Path(sys.argv[2]).resolve() / 'web/product-site/assets/starting-breaks'
sys.path[:0] = [str(sources / 'tools'), str(assets)]
import break_pack
import verify_assets

contract = verify_assets.load_contract(assets)
loops = [dict(name=a['name'], nsamples=a['frames'], bars=1,
              adpcm=(assets / (a['id'] + '.adpcm')).read_bytes()) for a in contract['assets']]
for a, loop in zip(contract['assets'], loops):
    assert hashlib.sha256(loop['adpcm']).hexdigest() == a['adpcm_sha256']
pack = break_pack.encode_pack(loops, contract['rate'])
assert hashlib.sha256(pack).hexdigest() == '8df1316157fc8ce8dcb87cfd267fea83790702ccd1963ae91c0de60ca255b582'

def round_trip_planes(data, delta):
    raw = np.frombuffer(data, dtype=np.uint8)
    nibbles = np.empty(2 * len(raw), dtype=np.uint8)
    nibbles[::2] = raw & 15
    nibbles[1::2] = raw >> 4
    if delta:
        nibbles[1:] = np.bitwise_xor(nibbles[1:], nibbles[:-1])
    packed = np.vstack([np.packbits(nibbles >> k & 1, bitorder='little') for k in range(4)])
    body = lzma.compress(packed.tobytes(), preset=6)
    planes = np.frombuffer(lzma.decompress(body), dtype=np.uint8).reshape(4, -1)
    restored = np.zeros_like(nibbles)
    for k in range(4):
        restored |= np.unpackbits(planes[k], bitorder='little')[:len(restored)] << k
    if delta:
        np.bitwise_xor.accumulate(restored, out=restored)
    assert (restored[::2] | restored[1::2] << 4).tobytes() == data
    return len(body)

raw_xz = lzma.compress(pack, preset=6)
assert lzma.decompress(raw_xz) == pack
print(json.dumps(dict(bank_bytes=len(pack), sha256=hashlib.sha256(pack).hexdigest(),
                      method='All three are byte-exact storage trials. Decoder size, RAM and random access excluded.',
                      xz6_bytes=len(raw_xz), xz6_nibble_planes_bytes=round_trip_planes(pack, False),
                      xz6_delta_nibble_planes_bytes=round_trip_planes(pack, True)), indent=2))
