# Stock BREAK fit, 21 November 2026

The five owner zones matched the nightly asset contract at `df61cfe067e56579ace27fc58341f722f4a7a0d9a476ad7d8e798a38413b504f`, asset tree `d39162169e15d061aebe6b0cdf4e02445d5cfcb8`. The independent fixture checks each encoded file, its decoded PCM and its WAV. The native bank at 22,050 Hz contains 109,394 bytes with SHA-256 `8df1316157fc8ce8dcb87cfd267fea83790702ccd1963ae91c0de60ca255b582`.

| Native source | Model | Linked bytes | Aligned capacity after 1,024 B reserve | Shortfall |
|---|---|---:|---:|---:|
| Integration `57f70f2f` | Elite | 551,492 | 144 | 109,250 |
| Integration `57f70f2f` | Pro | 551,484 | 160 | 109,234 |
| Combined `b5207372`, tree `d7251b5b` | Elite | 546,500 | 5,136 | 104,258 |
| Combined `b5207372`, tree `d7251b5b` | Pro | 546,492 | 5,152 | 104,242 |

The production packer rejected every one of the 31 nonempty owner-zone subsets on each of the four images. The production C reader accepted the entire authentic bank in a sufficiently large control region and a valid pack exactly filling each image’s available space. Adding one byte to those controls caused the native packer to reject each of them. The stock chooser and decoder fixtures passed on both source snapshots. The linked images and limits are covered by file digests in the two `*-fit.json` receipts.

On the standalone Elite source, compiling all 68 normally `-Os` or `-O2` application translation units with `-Oz` reduced the linked image by 37,264 bytes. The experimental image was 514,228 bytes and allowed 37,408 bytes after alignment and the reserve. It was still 71,986 bytes short and the unchanged native guard rejected a reference to ROM address `0xffce0064`. No package was accepted from this experiment. The stock ELFs contained only 144 bytes of identical whole-function bodies beyond the first copy on each board in each build. Two independent nibble-plane lossless storage trials also exceeded the unchanged XZ result of 97,776 bytes. None of these experiments changes a shipped setting, recovers enough capacity to qualify the owner bank or proves an absolute bound on future redesigns.

The SDK tag `AC79NN_SDK_V1.2.14_2026-10-13` resolved to `5fa84a9b2f723a5e9337ad79dc2ad741fc98fe2d` at `https://gitee.com/Jieli-Tech/fw-AC79_AIoT_SDK`. All three files at `cpu/wl82/tools` matched the repository's SHA-256 pins. JieLi Linux 20260730.1 built both model images. Running `MODEL=elite ./build.sh` and `MODEL=pro ./build.sh` creates the default `build` paths for `python3 measure.py FW NIGHTLY --source COMMIT`. The supplemental duplicate-body diagnostic takes `FW/build` and uses `readelf`. `plane_trial.py FW NIGHTLY` uses NumPy. To reproduce the size diagnostic, place `try_size.py` in a separate firmware root and run `MODEL=elite BOARD=smk37 python3 try_size.py --board smk37` with the same native inputs.
