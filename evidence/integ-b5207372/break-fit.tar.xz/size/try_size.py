"""Diagnostic only: make all application units favor size, including the normal O2 DSP units."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path('tools').resolve()))
import build
stock_commands = build.app_compile_commands

def favor_size(*args):
    commands, objects = stock_commands(*args)
    adjusted = [tuple('-Oz' if arg in ('-Os', '-O2') else arg for arg in command)
                for command in commands]
    print('DIAGNOSTIC: size flags substituted in', sum(a != b for a, b in zip(commands, adjusted)),
          'of', len(commands), 'application compile commands', flush=True)
    return adjusted, objects

build.app_compile_commands = favor_size
build.main()
