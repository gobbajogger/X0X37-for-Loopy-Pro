#!/usr/bin/env bash
set -eu
work=$(pwd)
export AC79_SDK="$work/build-inputs/sdk" JIELI_TOOLCHAIN="$work/dependencies/jieli-linux-toolchains-20260730.1" TMPDIR="$work/tmp" X0X_JOBS=4
cd fw
for model in elite pro; do
 MODEL="$model" ./build.sh >"../native/$model.log" 2>&1
 out="../native/$model"
 mkdir -p "$out"
 if [ "$model" = elite ]; then pkg=build/x0x-smk37-elite.fwsc; identity='SMK-37 Elite_900'; else pkg=build/x0x-smk37.fwsc; identity='SMK-37 Pro_900'; fi
 cp "$pkg" "$out"
 python3 tests/smk_pkg_test.py "$pkg" "$identity" >"$out/package-check.log"
done
