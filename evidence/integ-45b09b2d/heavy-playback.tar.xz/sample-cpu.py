import json
import time
from pathlib import Path

def read():
    return {
        p[0]: [int(v) for v in p[1:9]]
        for line in Path("/proc/stat").read_text().splitlines()
        if (p := line.split()) and p[0].startswith("cpu") and p[0][3:].isdigit()
    }

a = read()
time.sleep(15)
b = read()
for key in a:
    diff = [y-x for x,y in zip(a[key],b[key])]
    print(json.dumps(dict(cpu=key, utilization=1-(diff[3]+diff[4])/sum(diff), steal=diff[7]/sum(diff))))
