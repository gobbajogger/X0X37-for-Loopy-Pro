import hashlib, json, os, subprocess, tempfile
from pathlib import Path
p=Path(__file__).resolve().parent
orig=p.parent/'prior/45b09b2d'
for name,sweep in [('a',1),('b',2),('c',1),('d',2)]:
    with tempfile.TemporaryDirectory(dir=p) as tmp:
        env=dict(os.environ, LD_PRELOAD=str(p/'observe.so'), OBSERVE_PATH=str(p/f'{name}.txt'))
        r=subprocess.run([str(orig/'first/run'),tmp,str(orig/'personal-br1-zone1.wav'),'0','0','1024',str(sweep),'1','0'],env=env,capture_output=True,text=True,check=True)
        cpu=[int(row.split()[1]) for row in (p/f'{name}.txt').read_text().splitlines()]
        assert len(cpu)==1024
        metric=json.loads(r.stdout)
        assert round(float(metric['peak_ns']))==max(cpu)
        traces={f.name:[f.stat().st_size,hashlib.sha256(f.read_bytes()).hexdigest()] for f in Path(tmp).iterdir()}
        ref=next(item for line in (orig/'first/matrix.jsonl').read_text().splitlines() if (item:=json.loads(line))['sweep']==sweep and item['banks']==[1,0])
        assert traces==ref['traces']
        late=[i for i,t in enumerate(cpu) if t>=11609000]
        print(name,sweep,r.stderr.strip(),late,flush=True)
