#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <stdlib.h>

static int (*read_clock)(clockid_t, struct timespec *);
static uint64_t ticks[6144];
static unsigned count;
__attribute__((constructor)) static void start_observer(void) {
    read_clock = dlsym(RTLD_NEXT, "clock_gettime");
}
int clock_gettime(clockid_t clock, struct timespec *value) {
    int rc = read_clock(clock, value);
    if (clock == CLOCK_THREAD_CPUTIME_ID && rc == 0 && count < 6144)
        ticks[count++] = (uint64_t)value->tv_sec * 1000000000u + value->tv_nsec;
    return rc;
}
__attribute__((destructor)) static void finish_observer(void) {
    FILE *output = fopen(getenv("OBSERVE_PATH"), "w");
    if (!output) abort();
    for (unsigned i = 0; i + 5 < count; i += 6)
        fprintf(output, "%u %llu\n", i/6, (unsigned long long)(ticks[i+3]-ticks[i+2]+ticks[i+5]-ticks[i+4]));
    fclose(output);
}
