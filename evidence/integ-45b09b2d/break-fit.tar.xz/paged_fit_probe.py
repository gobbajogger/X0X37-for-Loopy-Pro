"""Measure independently decoded, lossless pages on actual stock app bytes.

Counts only stored payloads, page directory, and complete BREAK bank; excludes
decoder and relocation costs. Pages with no compression benefit stay raw.
This is a host sizing control, not an executable image.
"""
from pathlib import Path
import argparse
import hashlib
import json
import zlib

def raw_deflate(data):
    codec = zlib.compressobj(9,zlib.DEFLATED,-15)
    result = codec.compress(data) + codec.flush()
    assert zlib.decompress(result, -15) == data
    return result

def size(data, width):
    pages = [data[i:i+width] for i in range(0,len(data),width)]
    payload = sum(min(len(raw_deflate(p)),len(p)) for p in pages)
    return {"pages":len(pages), "payload_bytes":payload,
            "directory_bytes":len(pages)*3,
            "saving":len(data)-payload-len(pages)*3}

def measure(app, code_end, bank):
    maximum = 552672 - 1024
    output = {"app_bytes":len(app),"sha256":hashlib.sha256(app).hexdigest(),
              "native_code_end_offset":code_end, "bank_bytes":len(bank),"pages":{}}
    for width in [256,512,1024,2048,4096,8192,16384]:
        code = size(app[:code_end],width)
        rest = size(app[code_end:],width)
        samples = size(bank,width)
        result = {"code":code,"trailing_data":rest,"bank":samples}
        saved = code["saving"] + rest["saving"] + samples["saving"]
        result["shortfall_before_decoder_or_relocations"] = len(app) + len(bank) - saved - maximum
        result["code_only_shortfall_with_unchanged_bank"] = len(app) + len(bank) - code["saving"] - maximum
        output["pages"][str(width)] = result
    return output
if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("app",type=Path)
    ap.add_argument("bank",type=Path)
    ap.add_argument("code_end",type=int)
    args=ap.parse_args()
    print(json.dumps(measure(args.app.read_bytes(),args.code_end,args.bank.read_bytes()),indent=2))
