import concurrent.futures,datetime,hashlib,json,urllib.request,urllib.error
from pathlib import Path
assets=Path('build/i5/night/web/product-site/assets/starting-breaks')
prefix='https://gobbajogger.github.io/DnBOX-nightly/private-audio/'
def read(pair):
 path,want=pair
 try:
  req=urllib.request.Request(prefix+path,headers={'Cache-Control':'no-cache'})
  with urllib.request.urlopen(req,timeout=30) as r: got=hashlib.sha256(r.read()).hexdigest(); status=r.status
 except urllib.error.HTTPError as e: got=None; status=e.code
 return {'url':prefix+path,'http_status':status,'sha256':got,'expected':want,'pass':((status==404 and want is None) or (status==200 and got==want))}
pairs=[(w.stem+suffix,hashlib.sha256(w.read_bytes()).hexdigest()) for w in sorted(assets.glob('*.wav')) for suffix in ('','.wav')]
with concurrent.futures.ThreadPoolExecutor(3) as pool: rows=list(pool.map(read,pairs+[('absent-zone-negative-control.wav',None)]))
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':rows}
print(json.dumps(out,indent=2))
assert len(rows)==11 and all(r['pass'] for r in rows)
