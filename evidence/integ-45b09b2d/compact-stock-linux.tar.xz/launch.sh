#!/bin/bash
set -eu
d=$(dirname "$(realpath "$0")")
g=$(realpath "$d/../../vote-work/guest")
shares=()
fs() { shares+=(-virtfs "local,path=$2,mount_tag=$1,security_model=none,multidevs=remap,readonly=on"); }
fs ubin /usr/bin; fs uinclude /usr/include; fs usyslib /usr/lib/x86_64-linux-gnu; fs ugcc /usr/lib/gcc; fs ulibgcc /usr/libexec/gcc; fs py /usr/lib/python3.13; fs source "$d/code"
export LD_LIBRARY_PATH="$g/qhost/usr/lib/x86_64-linux-gnu"
exec taskset -c 7 "$g/qhost/usr/bin/qemu-system-x86_64" -accel tcg -cpu max -machine pc -smp 1 -m 384 -nodefaults -display none -monitor none -serial stdio -no-reboot -L "$g/qhost/usr/share/qemu" -bios "$g/qhost/usr/share/seabios/bios-256k.bin" -kernel "$g"/bootmods/boot/vmlinuz-* -initrd "$d/initramfs.gz" -append 'console=ttyS0 rdinit=/init panic=-1 quiet' "${shares[@]}"
