import stat,struct,sys,gzip,pathlib
from pathlib import Path
idx=0
def item(out,path,mode,data=b""):
 global idx
 idx+=1
 values=[idx,mode,0,0,1,0,len(data),0,0,0,0,len(path)+1,0]
 hdr=b"070701"+b"".join(f"{x:08x}".encode() for x in values)+path.encode()+b"\0"
 out.write(hdr+b"\0"*(-len(hdr)%4)+data+b"\0"*(-len(data)%4))
with gzip.open("initramfs.gz","wb",compresslevel=1) as out:
 for d in ["bin","dev","sys","proc","tmp","run","etc","home","home/tester","root","lib","lib64","usr","usr/lib","usr/share","modules","mnt","out","opt"]:
    item(out,d,stat.S_IFDIR|0o755)
 item(out,"bin/busybox",stat.S_IFREG|0o755,Path("qhost/usr/bin/busybox").read_bytes())
 item(out,"bin/sh",stat.S_IFLNK|0o777,b"busybox")
 item(out,"init",stat.S_IFREG|0o755,Path("init.sh").read_bytes())
 for p in sorted(Path("mods").glob("*.ko")):item(out,"modules/"+p.name,stat.S_IFREG|0o644,p.read_bytes())
 item(out,"TRAILER!!!",0)
