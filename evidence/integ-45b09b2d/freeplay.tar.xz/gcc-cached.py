#!/usr/bin/env python3
import concurrent.futures,os,pathlib,subprocess,sys,tempfile
root=pathlib.Path(__file__).resolve().parents[1]
cache=root/'dependencies'/'compiler-cache'
os.environ.update(CCACHE_DIR=str(root/'tmp'/'gcc-cache'),LD_LIBRARY_PATH=':'.join(str(cache/n/'usr/lib/x86_64-linux-gnu') for n in ['libfmt10','libhiredis1.1.0']))
args=sys.argv[1:]
sources=[a for a in args if a.endswith('.c')]
if len(sources)<=1 or '-c' in args or '-o' not in args:
 os.execv('/usr/bin/gcc',['gcc',*args])
with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as d:
 output=args.index('-o'); flags=[a for i,a in enumerate(args) if a not in sources and not a.startswith('-l') and i not in (output,output+1)]
 objects={a:str(pathlib.Path(d)/(str(i)+'.o')) for i,a in enumerate(sources)}
 def compile_unit(a):
  subprocess.run([cache/'ccache/usr/bin/ccache','/usr/bin/gcc',*flags,'-c',a,'-o',objects[a]],check=True)
 with concurrent.futures.ThreadPoolExecutor(3) as pool:
  list(pool.map(compile_unit,sources))
 subprocess.run(['/usr/bin/gcc',*(objects.get(a,a) for a in args)],check=True)
