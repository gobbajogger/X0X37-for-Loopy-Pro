from pathlib import Path
import json,os,subprocess,time,re
w=Path(__file__).resolve().parent
out=w/'alternate';out.mkdir(exist_ok=True)
src=(w/'fixed-work.c').read_text()
a='int misses=0; int64_t *times=calloc'
assert src.count(a)==1
src=src.replace(a,'int misses=0, wall_misses=0; int64_t wall_peak=0; int64_t *times=calloc')
a='if(times[i]>11609000)'
assert src.count(a)==1
src=src.replace(a,'if(w>11609000) ++wall_misses;\n  if(w>wall_peak) wall_peak=w;\n  '+a)
a='free(times); return 0;'
assert src.count(a)==1
src=src.replace(a,'printf("wall_misses=%d wall_peak_ns=%" PRId64 "\\n",wall_misses,wall_peak);\n '+a)
(out/'fixed-work-wall.c').write_text(src)
subprocess.run(['cc','-O2',str(out/'fixed-work-wall.c'),'-o',str(out/'fixed-work')],check=True)
allowed=sorted(os.sched_getaffinity(0))
def cpus():
 values={}
 for row in Path('/proc/stat').read_text().splitlines():
  v=row.split();k=v[0]
  if k.startswith('cpu') and k[3:].isdigit() and (i:=int(k[3:])) in allowed:values[i]=list(map(int,v[1:9]))
 return values
obs=[]
a=cpus()
for _ in range(3):
 time.sleep(2);b=cpus()
 metrics={}
 for i,x in a.items():
  d=[y-v for y,v in zip(b[i],x)];total=sum(d)
  if total:metrics[i]={'idle':d[3]/total,'steal':d[7]/total,'ticks':d}
 assert set(metrics)==set(allowed)
 obs.append(metrics);a=b
from statistics import median
scores={i:median(x[i]['idle'] for x in obs) for i in allowed}
candidate=max((i for i in allowed if i!=6),key=lambda i:(scores[i],-median(x[i]['steal'] for x in obs),-i))
selection={'allowed':allowed,'windows_seconds':2,'windows':obs,'idle_score_median':scores,'selected_cpu':candidate,'reference_cpu':6,'control_blocks_per_arm_per_round':4096,'rounds':2,'admission':'Both independently run candidate controls must have zero CPU and wall misses. Candidate must lower maximum wall time in both matched rounds, and CPU 6 must miss in at least one matched control.'}
(out/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
print('selected',candidate,flush=True)
controls=[]
for r,order in enumerate(((6,candidate),(candidate,6))):
 for i in order:
  run=subprocess.run(['taskset','-c',str(i),str(out/'fixed-work'),'4096','850000'],capture_output=True,text=True,check=True)
  (out/f'round-{r}-cpu-{i}.log').write_text(run.stdout)
  vals={k:int(v) for k,v in re.findall(r'(\w+)=([0-9]+)',run.stdout)}
  assert vals['blocks']==4096 and vals['iterations']==850000
  controls.append({'round':r,'cpu':i,**vals})
  print(controls[-1],flush=True)
selection['controls']=controls
matches=[({p['cpu']:p for p in controls if p['round']==r}) for r in range(2)]
assert len(set(p['state'] for p in controls))==1
selection['admitted']=all(m[candidate]['misses']==0 and m[candidate]['wall_misses']==0 and m[candidate]['wall_peak_ns']<m[6]['wall_peak_ns'] for m in matches) and any(m[6]['misses']+m[6]['wall_misses']>0 for m in matches)
(out/'verified.json').write_text(json.dumps(selection,indent=2)+'\n')
print('admitted',selection['admitted'],flush=True)
