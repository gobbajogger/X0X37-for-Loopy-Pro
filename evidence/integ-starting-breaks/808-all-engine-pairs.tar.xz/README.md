# Paired all-engine check for the 808 filter experiment

The stock and experimental runners match the executables in the companion stock-playback and 808-filter-trial reports. Each recorded process used CPU 3, ordinary shared host load, all five engines, both eleven-voice kits, the bank and parameter sweep specified in the row, and the original 1,024-block workload. The host harness uses CLOCK_THREAD_CPUTIME_ID around the two 256-frame engine renders/volumes in each 512-frame block. Each process reports the median of its 1,024 block samples. The summary compares these medians inside adjacent pairs. Every stdout, stderr, return code, audio hash and meter hash is in raw.jsonl. The predeclared order is in environment-before.json.

The grading deadline is 11,609 microseconds. The harness's legacy JSON stdout also contains its original rounded timing field. Use the exact-threshold CPU_misses and wall_misses in raw stderr and summary.json. All 16 runs completed, with canonical PCM and meter output in every case. See the original 808-filter-trial archive for the source patch, automation checks and FPU-aware symbol disassembly.

Companion SHA-256 values
stock-playback: 65cd067c9884522a411b6d2ed9044a70ed4500019040df07eb8fdd00f4b46dc6
808-filter-trial: 9384e19ef0028e4af0eeb817a57d37109d02526be0487e7c0bb44904818d6e05
