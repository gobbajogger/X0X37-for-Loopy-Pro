from pathlib import Path
import hashlib,io,json,tarfile
w=Path(__file__).resolve().parent
out=w.parents[1]/'logs/integ-bbef7562-808-all-engine-pairs.tar.xz'
rows=[json.loads(line) for line in (w/'raw.jsonl').read_text().splitlines()]
assert len(rows)==16 and all(x['status']==0 and x['matches'] for x in rows)
summary=json.loads((w/'summary.json').read_text())
hashes=json.loads((w/'environment-before.json').read_text())['sha']
assert len(hashes)==2
readme="""# Paired all-engine check for the 808 filter experiment

The stock and experimental runners match the executables in the companion stock-playback and 808-filter-trial reports. Each recorded process used CPU 3, ordinary shared host load, all five engines, both eleven-voice kits, the bank and parameter sweep specified in the row, and the original 1,024-block workload. The host harness uses CLOCK_THREAD_CPUTIME_ID around the two 256-frame engine renders/volumes in each 512-frame block. Each process reports the median of its 1,024 block samples. The summary compares these medians inside adjacent pairs. Every stdout, stderr, return code, audio hash and meter hash is in raw.jsonl. The predeclared order is in environment-before.json.

The grading deadline is 11,609 microseconds. The harness's legacy JSON stdout also contains its original rounded timing field. Use the exact-threshold CPU_misses and wall_misses in raw stderr and summary.json. All 16 runs completed, with canonical PCM and meter output in every case. See the original 808-filter-trial archive for the source patch, automation checks and FPU-aware symbol disassembly.

Companion SHA-256 values
stock-playback: 65cd067c9884522a411b6d2ed9044a70ed4500019040df07eb8fdd00f4b46dc6
808-filter-trial: 9384e19ef0028e4af0eeb817a57d37109d02526be0487e7c0bb44904818d6e05
"""
(w/'README.md').write_text(readme)
with tarfile.open(out,'w:xz',preset=5) as t:
 for k in sorted(['README.md','compare.py','pack.py','environment-before.json','environment-after.json','raw.jsonl','run.log','summary.json']):
  b=(w/k).read_bytes();h=tarfile.TarInfo(k);h.size=len(b);t.addfile(h,io.BytesIO(b))
print(out,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
for name,s in summary.items():print(name,s['median_paired_ratio'],s['median_ratio_by_first_arm'],s['paired_trial_wins'],s['misses'])
