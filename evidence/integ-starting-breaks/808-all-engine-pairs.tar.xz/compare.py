"""Bounded all-engine A/B using the existing stock and experimental binaries."""
from pathlib import Path
from statistics import median
import hashlib,json,os,re,subprocess,tempfile
w=Path(__file__).resolve().parent
r=w.parent
repo=r.parent/'integ-playback'
sample=r.parent/'nightly/web/product-site/assets/starting-breaks/personal-br1-zone1.wav'
binaries={'stock':r/'first/run','trial':r/'filter/run'}
cases=[(0,1,1),(2,3,2)]
orders=[['stock','trial'],['trial','stock'],['trial','stock'],['stock','trial']]
expected={(tuple(j['banks']),j['sweep']):j['traces'] for line in (r/'previous.jsonl').read_text().splitlines() if (j:=json.loads(line))}
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(sample)=='06ee634369363b5019453f66c9178f781e24371675636e47c66875bdf662187a'
def write(path,data): path.write_text(json.dumps(data,indent=2)+'\n')
def snap():
  return {'load':Path('/proc/loadavg').read_text().strip(),'cpu':next(l for l in Path('/proc/stat').read_text().splitlines() if l.startswith('cpu3 ')),'affinity':sorted(os.sched_getaffinity(0))}
assert os.sched_getaffinity(0)=={3}
write(w/'environment-before.json',{'host':os.uname().nodename,'environment':snap(),'sha':{k:sha(v) for k,v in binaries.items()},'sample_sha':sha(sample),'order':orders,'cases':cases,'blocks':1024,'condition':'Ordinary shared host load. Four pairs per workload, two in each order. A consistent candidate signal requires lower median in each order for each workload, at least three of four paired wins per workload, and confidence beyond observed run variability. Timings are render-thread per-run block medians. No retries or optional stopping.'})
rows=[]
with (w/'raw.jsonl').open('x',buffering=1) as log:
  for i,order in enumerate(orders):
    for a,b,sweep in (cases if i%2==0 else cases[::-1]):
      for arm in order:
        with tempfile.TemporaryDirectory(dir=w) as name:
          tmp=Path(name)
          args=[str(binaries[arm]),name,str(sample),'0','0','1024',str(sweep),str(a),str(b)]
          try:
            p=subprocess.run(args,cwd=repo,capture_output=True,text=True,timeout=150)
            status=p.returncode; err=p.stderr.strip(); out=p.stdout.strip()
          except subprocess.TimeoutExpired:
            status=124;err='Timed out at 150s';out=''
          traces={f.name:[f.stat().st_size,sha(f)] for f in tmp.iterdir()}
          x={'index':i,'order':order,'banks':[a,b],'sweep':sweep,'blocks':1024,'arm':arm,'status':status,'stderr':err,'stdout':out,'traces':traces,'matches':traces==expected[(a,b),sweep],'environment':snap()}
          log.write(json.dumps(x)+'\n');rows.append(x)
          print(i,a,b,sweep,arm,status,x['matches'],json.loads(out)['median_ns'] if out else '-',flush=True)
write(w/'environment-after.json',snap())
assert len(rows)==16 and all(x['status']==0 and x['matches'] and 'audible=31 drum_masks=2047/2047' in x['stderr'] for x in rows)
results={}
for a,b,sweep in cases:
  matching=[x for x in rows if x['banks']==[a,b] and x['sweep']==sweep]
  pairs=[]
  for i,order in enumerate(orders):
    t={x['arm']:json.loads(x['stdout'])['median_ns'] for x in matching if x['index']==i}
    pairs.append({'pair':i,'order':order,'medians_ns':t,'trial_over_stock':t['trial']/t['stock']})
  groups={first:[x['trial_over_stock'] for x in pairs if x['order'][0]==first] for first in binaries}
  results[f'{a}/{b} sweep {sweep}']={'pairs':pairs,'median_ratio_by_first_arm':{k:median(v) for k,v in groups.items()},'median_paired_ratio':median(p['trial_over_stock'] for p in pairs),'paired_trial_wins':sum(p['trial_over_stock']<1 for p in pairs),'misses':{arm:{k:sum(int(re.search(k+r'=(\d+)',x['stderr']).group(1)) for x in matching if x['arm']==arm) for k in ['CPU_misses','wall_misses']} for arm in binaries}}
write(w/'summary.json',results)
print(json.dumps(results),flush=True)
