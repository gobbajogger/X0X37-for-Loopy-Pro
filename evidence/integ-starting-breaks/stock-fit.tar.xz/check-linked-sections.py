from pathlib import Path
import hashlib,json,struct,sys

def image(elf):
    data=elf.read_bytes()
    assert data[:6]==b'\x7fELF\x01\x01'
    shoff=struct.unpack_from('<I',data,32)[0]
    size,count,ssidx=struct.unpack_from('<HHH',data,46)
    sh=[struct.unpack_from('<10I',data,shoff+i*size) for i in range(count)]
    names=data[sh[ssidx][4]:sh[ssidx][4]+sh[ssidx][5]]
    sections={names[s[0]:].split(b'\0',1)[0].decode():data[s[4]:s[4]+s[5]] for s in sh}
    payload=b''.join(sections[s] for s in ('.text','.ram_text','.c1_text','.data'))
    return payload+b'\xff'*(-len(payload)%4)+b'\0\xff\xff\xff'

expected=Path('../firmware/build/smk37-elite/x0x.bin').read_bytes()
out={}
for label in ['stock','baseline','relax','relax_lto_O2']:
    path=Path('../firmware/build/smk37-elite/x0x.elf') if label=='stock' else Path('build')/(label+'.elf')
    if not path.exists() or not path.stat().st_size:continue
    raw=image(path)
    out[label]=dict(image_bytes=len(raw),app_sha256=hashlib.sha256(raw).hexdigest(),xip_difference_from_stock=len(raw)-len(expected),stock_bytes=raw==expected)
assert out['stock']['stock_bytes'] and out['baseline']['stock_bytes'],out
print(json.dumps(out,indent=2))
