from pathlib import Path
import hashlib, json, lzma, os, re, subprocess, sys, zlib

root=Path('../firmware').resolve()
sys.path.insert(0,str(root/'tools'))
import build as b
tcroot=Path('../deps/jieli-linux-toolchains-20260730.1').resolve()
b.BOARD='smk37'
b.MODEL='elite'
b.OUT=root/'build/smk37-elite'
_,objs=b.app_compile_commands([], True, '0')
scratch=Path('build').resolve()
linkargs=[str(tcroot/'pi32v2/bin/ld'),'-plugin',str(tcroot/'pi32v2/bin/LLVMgold.so'),'-plugin-opt=-inline-threshold=0','-plugin-opt=-inlinehint-threshold=0','-plugin-opt=-inlinecold-threshold=0','-plugin-opt=-enable-tail-merge','-plugin-opt=-tail-merge-size=1','-plugin-opt=-tail-merge-threshold=10000','-plugin-opt=-function-sections','-plugin-opt=-data-sections','-plugin-opt=-fp-contract=off','--sort-section=alignment','--gc-sections','-e','_start','-T',str(b.OUT/'app.ld'),*map(str,objs)]
assert all(p.is_file() for p in objs), [str(p) for p in objs if not p.is_file()]
os.environ['TMPDIR']=str(scratch/'tmp')
out={'source':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'native_reference_image':hashlib.sha256((b.OUT/'x0x.bin').read_bytes()).hexdigest(), 'link_trials':{}}
base=0x02000120
def sections(elf):
    data=subprocess.check_output([str(tcroot/'common/bin/objdump'),'-h',str(elf)],text=True)
    return {s[1]:int(s[2],16) for l in data.splitlines() if (s:=l.split()) and len(s)>=5 and s[0].isdigit()}
for name,options in [('baseline',[]),('relax',['--relax']),('relax_lto_O2',['--relax','-plugin-opt=O2'])]:
    elf=scratch/(name+'.elf')
    result=subprocess.run([*linkargs,*options,'-o',str(elf)],cwd=root,capture_output=True,text=True)
    trial=dict(exit=result.returncode, options=options)
    out['link_trials'][name]=trial
    if result.returncode: trial['error']=result.stderr.strip()[-1200:]
    else:
        sizes=sections(elf)
        trial['xip_sections']={s:sizes.get(s,0) for s in ('.text','.ram_text','.c1_text','.data')}
        trial['image_bytes']=sum(trial['xip_sections'].values())+4
        trial['elf_sha256']=hashlib.sha256(elf.read_bytes()).hexdigest()
    print(name,trial,flush=True)
for model,folder in [('elite','smk37-elite'),('pro','smk37')]:
    elf=root/'build'/folder/'x0x.elf'
    if not (elf.parent/'x0x.bin').exists(): continue
    app=(elf.parent/'x0x.bin').read_bytes()
    syms=subprocess.check_output(['readelf','-Ws',str(elf)],text=True)
    ends=[]
    for line in syms.splitlines():
        fields=line.split()
        if len(fields)>=8 and fields[3]=='FUNC':
            start=int(fields[1],16)-base
            if 0<=start<len(app): ends.append(start+int(fields[2]))
    cut=max(ends)
    bank=(Path('assets/starting-breaks/starting-break-pack.bin')).read_bytes()
    limit=552672-1024
    tail=app[cut:]
    result={'app_sha256':hashlib.sha256(app).hexdigest(),'app_bytes':len(app),'native_xip_function_end':cut,'trailing_bytes':len(tail),'bank_bytes':len(bank),'estimated_overshoot_before_decoder':{}}
    for name,encoder,decoder in [('zlib9',lambda x:zlib.compress(x,9),zlib.decompress),('xz9',lambda x:lzma.compress(x,preset=9),lzma.decompress)]:
        a=encoder(tail); p=encoder(bank)
        assert decoder(a)==tail and decoder(p)==bank
        result['estimated_overshoot_before_decoder'][name]=dict(stored_trailing_bytes=len(a),stored_bank_bytes=len(p),deficit=cut+len(a)+len(p)-limit)
    out[model]=result
    print(model,result,flush=True)
Path('../logs/breakfit-size-options.json').write_text(json.dumps(out,indent=2)+'\n')
