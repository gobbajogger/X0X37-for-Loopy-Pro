from pathlib import Path
import concurrent.futures, hashlib, os, shlex, subprocess
w=Path(__file__).resolve().parent
root=Path(os.environ['DNBOX_PLAYBACK_ROOT']).resolve()
os.chdir(root)
args=subprocess.check_output(['sh','-c','. tests/host/original_build.sh; printf "%s\\n" "$ORIGINAL_FLAGS" "$ORIGINAL_SOURCES"'],text=True).splitlines()
flags,sources=map(shlex.split,args)
flags=['-pipe','-O2','-ffp-contract=off','-std=c99','-Wno-unused-function','-Wno-unused-parameter','-DX0X_HOST','-iquote',str(root/'firmware/src/dsp'),'-iquote',str(root/'tests/host'),*flags,'-Ifirmware/src','-Ifirmware/src/app','-Ifirmware/src/dsp','-I'+str(root/'build/gen')]
sources=[str(w/'first/bank-stress.c'),*sources]
o=w/'objects';o.mkdir(exist_ok=True)
def compile_unit(pair):
 idx,src=pair
 obj=o/f'{idx:02}-{Path(src).stem}.o'
 if not obj.exists():
  temp=obj.with_suffix('.partial')
  log=obj.with_suffix('.log')
  cmd=['cc',*flags,'-MMD','-MF',str(obj.with_suffix('.d')),'-c',src,'-o',str(temp)]
  with log.open('w') as f:
   subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
  temp.replace(obj)
 print(f'{idx:02} {src}',flush=True)
 return str(obj)
with concurrent.futures.ThreadPoolExecutor(3) as ex:
 objects=list(ex.map(compile_unit,enumerate(sources)))
subprocess.run(['cc',*objects,'-lm','-o',str(w/'first/run')],check=True)
print('binary',hashlib.sha256((w/'first/run').read_bytes()).hexdigest())
