from pathlib import Path
from collections import defaultdict
from statistics import median
import hashlib,json,re
w=Path(__file__).resolve().parent
def rows(path):
 return [json.loads(line) for line in path.read_text().splitlines()]
canonical={(tuple(p['banks']),p['sweep']):p['traces'] for p in rows(w/'previous.jsonl')}
def measurement(x,key):
 return float(re.search(r'\b'+key+r'=([0-9.]+)\b',x['stderr']).group(1))
def matrix(path):
 m=rows(path)
 assert len(m)==len(canonical)==32 and {(tuple(x['banks']),x['sweep']) for x in m}==set(canonical)
 for x in m:
  assert x['blocks']==1024 and x['status']==0
  assert all(measurement(x,k)==v for k,v in [('audible',31),('packets',131072)])
  assert 'drum_masks=2047/2047' in x['stderr']
  assert len(x['traces'])==2 and x['traces']==canonical[tuple(x['banks']),x['sweep']]
  assert x['traces']['audio.i32'][0]==4194304 and x['traces']['peak-scope.bin'][0]==276480
 return {'blocks':sum(x['blocks'] for x in m),'cases':len(m),'cpu_misses':int(sum(measurement(x,'CPU_misses') for x in m)),'wall_misses':int(sum(measurement(x,'wall_misses') for x in m)),'peak_cpu_us':max(measurement(x,'CPU_peak_us') for x in m),'peak_wall_us':max(measurement(x,'wall_peak_us') for x in m),'median_of_case_medians_us':median(json.loads(x['stdout'])['median_ns'] for x in m)/1000,'matched_pcm_digest_count':len(m),'matched_meter_scope_digest_count':len(m),'audible_parts':5,'voices_per_kit':11}
out={'source':'bbef756236ddf54cebaf8ccf9071b8975e7e8839','tree':'b469f59b5bbeb963e6d4ec899d03399fabb6fc71','parents':['cfbdb7ae1592edbb7ec96b6f9fcd00f26bd37e54','f013ecc653f2b9f0006e976a1097250e9356ce14'],'fixture_sha256':'06ee634369363b5019453f66c9178f781e24371675636e47c66875bdf662187a','deadline_us':11609,'clock':'CLOCK_THREAD_CPUTIME_ID and CLOCK_MONOTONIC','run_sha256':hashlib.sha256((w/'first/run').read_bytes()).hexdigest(),'qualification':{}}
for label in ('first','second'):
 p=w/label/'matrix.jsonl'
 if p.exists() and len(rows(p))==32:out['qualification'][label]=matrix(p)
before=w/'second/environment-before.log'; after=w/'second/environment-after.log'
if before.exists() and after.exists():
 def cpu_ticks(p):
  return [int(v) for v in next(x for x in p.read_text().splitlines() if x.startswith('cpu6 ')).split()[1:9]]
 changes=[b-a for a,b in zip(cpu_ticks(before),cpu_ticks(after),strict=True)]
 assert all(v>=0 for v in changes) and sum(changes)>0,changes
 out['quiet_cpu6_proc_stat_ticks']=dict(zip(('user','nice','system','idle','iowait','irq','softirq','steal'),changes,strict=True))
 out['quiet_cpu6_proc_stat_steal_percent']=100*changes[-1]/sum(changes)
neg=rows(w/'first/negative.jsonl')
assert len(neg)==1 and neg[0]['status']==3 and measurement(neg[0],'audible')==23
out['muted_bass_B_control']={'status':3,'audible_mask':23,'expected_mask':31,'blocks':neg[0]['blocks']}
out['constant_work']=dict(x.split('=') for x in (w/'fixed-work.log').read_text().strip().splitlines()[-1].split())
out['profile']=[{'banks':x['banks'],'sweep':x['sweep'],'main_executable_samples':x['samples_on_render_image'],'lib_or_kernel_samples':x['meta']['outside'],'top':x['top'][:5]} for x in json.loads((w/'profile/summary.json').read_text())]
trial=w/'trial'
if (trial/'ab.jsonl').exists():
 pairs=defaultdict(dict)
 for x in rows(trial/'ab.jsonl'):
  assert x['traces']==canonical[tuple(x['banks']),x['sweep']]
  pairs[(x['repeat'],*x['banks'],x['sweep'])][x['arm']]=x['measured']['median_ns']
 if len(pairs)==16 and all(len(v)==2 for v in pairs.values()):
  ratios=[v['trial']/v['stock'] for v in pairs.values()]
  out['triangle_trial']={'matched_pairs':16,'faster_pairs':sum(r<1 for r in ratios),'median_candidate_to_stock_ratio':median(ratios),'native_909_text_delta_bytes':-104,'native_909_data_delta_bytes':0,'native_909_bss_delta_bytes':0}
 if (trial/'stem.log').exists():
  stem_by_mode=defaultdict(list)
  for line in (trial/'stem.log').read_text().splitlines():
   m,r,s,c=map(int,line.split());stem_by_mode[m].append(c/s)
  if len(stem_by_mode)==2 and all(len(v)==16 for v in stem_by_mode.values()):
   out['triangle_kit_measurement']={k:{'paired_batches':len(v),'faster_pairs':sum(r<1 for r in v),'median_candidate_to_stock_ratio':median(v),'byte_identical_PCM_and_state_blocks':len(v)*512} for k,v in stem_by_mode.items()}
(w/'verified.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['qualification'],indent=2),out.get('triangle_trial'),out.get('triangle_kit_measurement'),flush=True)
