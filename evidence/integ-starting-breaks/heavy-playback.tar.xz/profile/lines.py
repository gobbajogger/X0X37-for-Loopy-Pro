from pathlib import Path
from collections import Counter
import subprocess
w=Path(__file__).resolve().parent
exe=w.parent/'first/run'
def syms(path):
 return {v[3]:(int(v[0],16),int(v[1],16)) for line in subprocess.check_output(['nm','-n','-S','--defined-only',str(path)],text=True).splitlines() if len(v:=line.split(None,3))==4 and v[2].lower()=='t'}
binary=syms(exe)
for name,obj in [('d9_render','01-drum909.o'),('voice_run','02-drum808.o')]:
 if not (w/obj).exists(): continue
 off,size=binary[name];local,_=syms(w/obj)[name]; samples=Counter()
 for p in sorted(w.glob('*.samples')):
  for line in p.read_text().splitlines()[1:]:
   addr,k=line.split();addr=int(addr,16)
   if off<=addr<off+size:samples[addr]+=int(k)
 vals=[]
 for a in samples:
  addr=local+a-off
  loc=subprocess.check_output(['addr2line','-f','-e',str(w/obj),hex(addr)],text=True).splitlines()
  vals.append(((loc[0],loc[1].split('/')[-1]),samples[a]))
 grouped=Counter()
 for x,k in vals:grouped[x]+=k
 print(name, sum(samples.values()),*grouped.most_common(18),sep='\n')
