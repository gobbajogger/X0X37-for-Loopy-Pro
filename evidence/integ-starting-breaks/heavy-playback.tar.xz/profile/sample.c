#define _GNU_SOURCE
#include <dlfcn.h>
#include <inttypes.h>
#include <link.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <ucontext.h>
static uintptr_t image_base, text_end;
static volatile sig_atomic_t *bins, outside, foreground, active;
static unsigned long calls;
static int (*clockfn)(clockid_t,struct timespec*);
static int main_image(struct dl_phdr_info *d, size_t size, void *ctx) {
    (void)size;(void)ctx;
    if (d->dlpi_name[0]) return 0;
    image_base=d->dlpi_addr;
    for (int i=0;i<d->dlpi_phnum;i++) {
        const ElfW(Phdr) *p=&d->dlpi_phdr[i];
        if (p->p_type==PT_LOAD && (p->p_flags&PF_X) && text_end < p->p_vaddr+p->p_memsz)
            text_end=p->p_vaddr+p->p_memsz;
    }
    return 1;
}
static void sample(int s,siginfo_t *info,void *ctx) {
    (void)s;(void)info;
    uintptr_t pc=(uintptr_t)((ucontext_t*)ctx)->uc_mcontext.gregs[REG_RIP];
    if (!active) { ++foreground; return; }
    if (pc < image_base || pc-image_base>=text_end) { ++outside; return; }
    ++bins[(pc-image_base)>>4];
}
__attribute__((constructor)) static void setup(void) {
    clockfn=dlsym(RTLD_NEXT,"clock_gettime");
    if (!clockfn || !getenv("DNBOX_PROFILE")) return;
    dl_iterate_phdr(main_image,NULL);
    bins=calloc((text_end>>4)+1,sizeof(*bins));
    if (!bins || !text_end) abort();
    struct sigaction sa={.sa_sigaction=sample,.sa_flags=SA_SIGINFO|SA_RESTART};
    sigemptyset(&sa.sa_mask);
    struct itimerval p={{0,1000},{0,1000}};
    if (sigaction(SIGPROF,&sa,NULL)||setitimer(ITIMER_PROF,&p,NULL)) abort();
}
int clock_gettime(clockid_t id,struct timespec *ts) {
    if (!clockfn) clockfn=dlsym(RTLD_NEXT,"clock_gettime");
    if (id==CLOCK_THREAD_CPUTIME_ID) {unsigned phase=calls++%6; active=(phase==2||phase==4);}
    return clockfn(id,ts);
}
__attribute__((destructor)) static void finish(void) {
    if (!bins) return;
    struct itimerval stop={{0,0},{0,0}};
    setitimer(ITIMER_PROF,&stop,NULL);
    FILE *f=fopen(getenv("DNBOX_PROFILE"),"w");
    if (!f) abort();
    fprintf(f,"calls=%lu foreground=%d outside=%d\n",calls,foreground,outside);
    for(uintptr_t i=0;i<=(text_end>>4);i++) if(bins[i]) fprintf(f,"%" PRIxPTR " %d\n",i<<4,bins[i]);
    fclose(f);
}
