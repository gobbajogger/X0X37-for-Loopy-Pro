from pathlib import Path
import concurrent.futures, hashlib, os, shlex, subprocess
w=Path(__file__).resolve().parents[1]
root=w.parent/'integ-playback'
os.chdir(root)
args=subprocess.check_output(['sh','-c','. tests/host/original_build.sh; printf "%s\\n" "$ORIGINAL_FLAGS" "$ORIGINAL_SOURCES"'],text=True).splitlines()
flags,sources=map(shlex.split,args)
flags=['-pipe','-O2','-ffp-contract=off','-std=c99','-Wno-unused-function','-Wno-unused-parameter','-DX0X_HOST','-iquote',str(root/'firmware/src/dsp'),'-iquote',str(root/'tests/host'),*flags,'-Ifirmware/src','-Ifirmware/src/app','-Ifirmware/src/dsp','-I'+str(root/'build/gen')]
sources=[str(w/'first/bank-stress.c'),*sources]

import sys
for idx in map(int,sys.argv[1:]):
 src=sources[idx];obj=w/'objects'/f'{idx:02}-{Path(src).stem}.o';out=w/'profile'/obj.name
 subprocess.run(['cc',*flags,'-g','-c',src,'-o',str(out)],check=True)
 hashes=[]
 for k,arm in enumerate((obj,out)):
  raw=w/'profile'/f'.{idx}-{k}.text'
  subprocess.run(['objcopy','--only-section=.text','-O','binary',str(arm),str(raw)],check=True)
  hashes.append(hashlib.sha256(raw.read_bytes()).hexdigest())
 assert hashes[0]==hashes[1],(src,hashes)
 print(idx,src,hashes[0],flush=True)
