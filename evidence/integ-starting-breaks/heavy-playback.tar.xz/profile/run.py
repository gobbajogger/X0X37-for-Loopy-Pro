from bisect import bisect_right
from collections import Counter
from pathlib import Path
import hashlib,json,os,subprocess,tempfile
w=Path(__file__).resolve().parent
root=w.parents[1]/'integ-playback'
p=w.parent/'first/run'
wav=root.parent/'nightly/web/product-site/assets/starting-breaks/personal-br1-zone1.wav'
symbols=[]
for line in subprocess.check_output(['nm','-n','-S','--defined-only',p],text=True).splitlines():
 v=line.split(None,3)
 if len(v)==4 and v[2].lower()=='t':
  symbols.append((int(v[0],16),int(v[1],16),v[3]))
starts=[x[0] for x in symbols]
res=[]
for a,b,sweep in ((0,1,1),(1,1,2),(2,3,1),(3,2,2)):
 label=f'{a}-{b}-{sweep}'; raw=w/f'{label}.samples'
 with tempfile.TemporaryDirectory(dir=w) as d:
  run=subprocess.run([str(p),d,str(wav),'0','0','1024',str(sweep),str(a),str(b)],capture_output=True,text=True,env={**os.environ,'DNBOX_PROFILE':str(raw),'LD_PRELOAD':str(w/'sample.so')},cwd=root,preexec_fn=lambda: os.sched_setaffinity(0,{4}),check=True)
  first,*rows=raw.read_text().splitlines()
  values={k:int(v) for k,v in (x.split('=') for x in first.split())}
  assert values['calls']==6*1024,(label,values)
  assert 'audible=31 drum_masks=2047/2047' in run.stderr,run.stderr
  counts=Counter()
  for line in rows:
   addr,num=line.split();addr=int(addr,16);i=bisect_right(starts,addr)-1
   name=symbols[i][2] if i>=0 and symbols[i][0]+symbols[i][1]>addr else 'unmapped padding'
   counts[name]+=int(num)
  hashes={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in Path(d).glob('*')}
  case={'banks':[a,b],'sweep':sweep,'samples_on_render_image':counts.total(),'top':counts.most_common(30),'meta':values,'hashes':hashes}
  res.append(case);print(label,counts.total(),counts.most_common(8),values,flush=True)
(w/'summary.json').write_text(json.dumps(res,indent=2)+'\n')
