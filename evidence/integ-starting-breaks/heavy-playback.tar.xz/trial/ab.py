from pathlib import Path
from collections import defaultdict
import hashlib,json,os,re,statistics,subprocess,tempfile
w=Path(__file__).resolve().parent
r=w.parents[1]/'integ-playback'
sample=r.parent/'nightly/web/product-site/assets/starting-breaks/personal-br1-zone1.wav'
prior={(tuple(p['banks']),p['sweep']):p['traces'] for l in (w.parent/'previous.jsonl').read_text().splitlines() if (p:=json.loads(l))}
pairs=[(0,1,1),(2,3,1),(1,1,2),(3,2,2)]
os.sched_setaffinity(0,{4})
with (w/'ab.jsonl').open('w') as f:
 for rep in range(4):
  for case,(a,b,sweep) in enumerate(pairs):
   order=['stock','trial'] if (rep+case)%2==0 else ['trial','stock']
   for arm in order:
    exe=w/'run' if arm=='trial' else w.parent/'first/run'
    with tempfile.TemporaryDirectory(dir=w) as d:
     p=subprocess.run([str(exe),d,str(sample),'0','0','1024',str(sweep),str(a),str(b)],cwd=r,capture_output=True,text=True,check=True)
     hashes={x.name:[x.stat().st_size,hashlib.sha256(x.read_bytes()).hexdigest()] for x in Path(d).glob('*')}
     assert hashes==prior[(a,b),sweep],(arm,a,b,sweep,hashes)
     assert 'audible=31 drum_masks=2047/2047' in p.stderr
     row={'arm':arm,'repeat':rep,'banks':[a,b],'sweep':sweep,'measured':json.loads(p.stdout),'summary':p.stderr.strip(),'traces':hashes}
     print(json.dumps(row),file=f,flush=True)
 print('32 paired-arm runs, all 64 trace comparisons match canonical checksums.')
