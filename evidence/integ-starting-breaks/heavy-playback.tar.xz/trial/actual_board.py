from pathlib import Path
import hashlib,json,struct
w=Path(__file__).resolve().parent
def load(path):
 raw=path.read_bytes()
 assert raw[:6]==b"\x7fELF\x01\x01"
 e=struct.unpack_from('<16sHHIIIIIHHHHHH',raw)
 sh=[struct.unpack_from('<10I',raw,e[6]+n*e[11]) for n in range(e[12])]
 strings=sh[e[13]];names=raw[strings[4]:strings[4]+strings[5]]
 out={}
 for h in sh:
  name=names[h[0]:].split(b'\0',1)[0].decode()
  if h[2]&2:out[name]=(h[5],hashlib.sha256(raw[h[4]:h[4]+h[5]]).hexdigest() if h[1]!=8 else 'BSS')
 return out
results={}
for model,dirname in [('elite','smk37-elite'),('pro','smk37')]:
 actual=w.parents[1]/'firmware/build'/dirname/'o2/dsp_drum909.o'
 a=load(actual);b=load(w/f'{model}-stock.o');c=load(w/f'{model}-trial.o')
 assert a==b,(model,[k for k in set(a)|set(b) if a.get(k)!=b.get(k)])
 changes={k:[a.get(k),c.get(k)] for k in set(a)|set(c) if a.get(k)!=c.get(k)}
 results[model]={'board_allocated_sections_matching':len(a),'trial_changed':changes}
 print(model,len(a),'allocated sections match stock build;',[(k,a[k][0],c[k][0]) for k in changes])
(w/'actual-board.json').write_text(json.dumps(results,indent=2)+'\n')
