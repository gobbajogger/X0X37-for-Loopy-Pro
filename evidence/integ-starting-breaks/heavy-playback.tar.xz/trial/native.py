import os,sys,subprocess,shlex,hashlib
from pathlib import Path
w=Path(__file__).resolve().parent
r=w.parents[1]/'integ-playback'
os.chdir(r)
sys.path.insert(0,str(r/'tools'))
tool_dir=r.parent/'deps/jieli-linux-toolchains-20260730.1'
os.environ['JIELI_TOOLCHAIN']=str(tool_dir)
import build
class Captured(Exception):pass
def capture(*cmds):
    targets=[x for x in cmds if x[0]=='cc' and any(str(a).endswith('/dsp/drum909.c') for a in x)]
    assert len(targets)==1,len(targets)
    original=targets[0]
    for label,src in [('stock',r/'firmware/src/dsp/drum909.c'),('trial',w/'drum909.c')]:
        output=w/f'{build.MODEL}-{label}.o'
        args=list(original[1:])
        args[args.index('-c')+1]=str(src)
        args[args.index('-o')+1]=str(output)
        cmd=[str(tool_dir/'pi32v2/bin/clang'),'-target','pi32v2','-iquote',str(r/'firmware/src/dsp'),*map(str,args)]
        print(shlex.join(cmd),flush=True)
        subprocess.run(cmd,check=True)
        print(subprocess.check_output(['size',str(output)],text=True))
        table=subprocess.check_output([str(tool_dir/'common/bin/objdump'),'-h',str(output)],text=True)
        (w/f'{build.MODEL}-{label}-sections.txt').write_text(table)
    raise Captured
build.tc_all=capture
build.BOARD='smk37'
for build.MODEL in ('elite','pro'):
    try:build.build_app()
    except Captured:pass
