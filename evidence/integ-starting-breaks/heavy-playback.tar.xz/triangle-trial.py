from pathlib import Path
import hashlib,subprocess
w=Path(__file__).resolve().parent
root=w.parent/'integ-playback'
a=w/'trial';a.mkdir(exist_ok=True)
source=(root/'firmware/src/dsp/drum909.c').read_text()
old='''D9_INLINE float d9_diode16(float x) { return d9_tanh_inline(1.6f * x) * D9_INV_TANH_1_6; }
D9_INLINE float d9_diode20(float x) { return d9_tanh_inline(2.0f * x) * D9_INV_TANH_2_0; }'''
new='''D9_INLINE float d9_triangle_diode(uint32_t phase, float drive, float gain)
{
    /* The triangle lies in [-1, 1]. Both fixed drives stay inside the tanh table. */
    const float u = d9_tri(phase) * drive;
    const float a = fm_fabsf(u) * X0X_TANH_SCALE;
    const unsigned i = (unsigned)a;
    const float t0 = x0x_tanh_raw[i];
    const float t1 = x0x_tanh_raw[i + 1u];
    const float t = t0 + (t1 - t0) * (a - (float)i);
    return (u < 0.0f ? -t : t) * gain;
}'''
assert source.count(old)==1
source=source.replace(old,new)
import re
source,n16=re.subn(r'd9_diode16\(d9_tri\(([^()]+)\)\)',r'd9_triangle_diode(\1, 1.6f, D9_INV_TANH_1_6)',source)
source,n20=re.subn(r'd9_diode20\(d9_tri\(([^()]+)\)\)',r'd9_triangle_diode(\1, 2.0f, D9_INV_TANH_2_0)',source)
assert n16==1 and n20==5
candidate=a/'drum909.c';candidate.write_text(source)
prefix=(w/'build-objects.py').read_text().split('o=w/')[0]
exec(compile(prefix,str(w/'build-objects.py'),'exec'))
obj=a/'01-drum909.o'
subprocess.run(['cc',*flags,'-c',str(candidate),'-o',str(obj)],check=True)
objects=sorted((w/'objects').glob('*.o'))
assert len(objects)==72 and objects[1].name==obj.name
objects[1]=obj
subprocess.run(['cc',*map(str,objects),'-lm','-o',str(a/'run')],check=True)
print(subprocess.check_output(['size',str(w/'objects'/obj.name),str(obj)],text=True))
raw=subprocess.run(['diff','-u','--label','a/firmware/src/dsp/drum909.c','--label','b/firmware/src/dsp/drum909.c',str(root/'firmware/src/dsp/drum909.c'),str(candidate)],capture_output=True,check=False).stdout
(a/'triangle.patch').write_bytes(raw)
