from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,time
w=Path(__file__).resolve().parent
repo=Path(os.environ['DNBOX_PLAYBACK_ROOT']).resolve()
sample=Path(os.environ['DNBOX_BREAK_FIXTURE']).resolve()
assert hashlib.sha256(sample.read_bytes()).hexdigest()=='06ee634369363b5019453f66c9178f781e24371675636e47c66875bdf662187a'
blocks=int(sys.argv[1])
mode=sys.argv[2]
assert mode in ('smoke','matrix','negative')
pairs=[(0,1),(2,3),(3,2),(2,2),(3,3),(0,0),(1,1)]+[(a,b) for a in range(4) for b in range(4) if a!=b and (a,b) not in ((0,1),(2,3),(3,2))]
assert len(set(pairs))==len(pairs)==16
if mode=='smoke':pairs=[(0,1),(2,3),(3,2)]
if mode=='negative':pairs=[(2,3)]
sweeps=[1,2] if mode=='matrix' else [1]
with (w/(mode+'.jsonl')).open('x') as log:
    cases=0
    failures=0
    for sweep in sweeps:
      for a,b in pairs:
        with tempfile.TemporaryDirectory(dir=w) as dest:
            out=Path(dest)
            cmd=[str(w/'run'),dest,str(sample),'0','0',str(blocks),str(sweep),str(a),str(b)]
            env=dict(os.environ)
            if mode=='negative':env['INTEG_NEGATIVE_SILENT_B']='1'
            try:
                p=subprocess.run(cmd,cwd=repo,capture_output=True,text=True,timeout=120,env=env)
                status=p.returncode; stderr=p.stderr.strip(); stdout=p.stdout[-3000:].strip()
            except subprocess.TimeoutExpired:
                status=124; stderr='Timed out after 120 seconds'; stdout=''
            payload={'banks':[a,b],'sweep':sweep,'blocks':blocks,'status':status,'stderr':stderr,'stdout':stdout}
            data={}
            for f in sorted(out.iterdir()):
                raw=f.read_bytes()
                data[f.name]=[len(raw),hashlib.sha256(raw).hexdigest()]
            payload['traces']=data
            log.write(json.dumps(payload)+'\n')
            log.flush()
            print(a,b,sweep,status,stderr[-320:],flush=True)
            cases+=1
            if mode=='negative':
                valid=status==3 and 'audible=23 ' in stderr
            else:
                valid=status==0 and data.get('audio.i32',[0])[0]==blocks*4096 and 'audible=31 ' in stderr and 'drum_masks=2047/2047' in stderr
            failures+=not valid
    print(cases,'cases;',failures,'unexpected results')
    sys.exit(1 if failures or cases!=len(pairs)*len(sweeps) else 0)
