# Combined stock playback

This packet tests firmware commit bbef756236ddf54cebaf8ccf9071b8975e7e8839, which combines integration cfbdb7ae and Sound f013ecc6. The Git tree is b469f59b5bbeb963e6d4ec899d03399fabb6fc71. The 512-frame render interval has an 11,609 µs deadline. Each 32,768-block sweep combines every ordered pair of the four bass banks with two automation settings, both 11-row kits, BREAK, effects and MIDI. The candidate acceptance checks are in verified.json. The run harness reports coverage and trace integrity separately from timing. Positive harness exit alone does not establish zero dropouts.

The first sweep ran under ordinary local load. The second started after local native builds, BREAK fixtures and DSP trials ended. CPU 6 reported 18.31% steal across the second sweep. The complete per-sweep render-thread and wall-time outcomes are in verified.json. This host measure does not establish physical-board timing.

The 32 historical PCM and 32 meter/scope checksums come from evidence/integ-45b09b2d/heavy-playback.tar.xz in the firmware repository. first/negative.jsonl is the intentional muted-B control. The fixed-work control has an unchanging arithmetic workload and shares playback CPU 6. It ran during ordinary workspace activity.

## Reproduction

Set DNBOX_PLAYBACK_ROOT to a clean matching firmware checkout. Set DNBOX_BREAK_FIXTURE to the nightly repository's web/product-site/assets/starting-breaks/personal-br1-zone1.wav. Its SHA-256 is 06ee634369363b5019453f66c9178f781e24371675636e47c66875bdf662187a. Extract the packet to a fresh directory and save its recorded JSONL and logs before regenerating. Rebuild the stock headers in the firmware checkout with the following commands.

    X0X_GEN_CACHE=0 python3 -c 'import sys; sys.path.insert(0,"tools"); import build; build.BOARD="smk37"; build.MODEL="elite"; build.generate()'
    python3 tools/check_original_inputs.py

Run these commands in the extracted directory.

    patch -s -o first/bank-stress.c "$DNBOX_PLAYBACK_ROOT/tests/host/audio_path_stress.c" <first/bank-stress.patch
    python3 build-objects.py
    cp first/run second/run
    taskset -c 6 python3 first/run-matrix.py 1024 matrix
    taskset -c 6 python3 first/run-matrix.py 128 negative
    taskset -c 6 python3 second/run-matrix.py 1024 matrix
    cc -O2 fixed-work.c -o fixed-work
    taskset -c 6 ./fixed-work 32768 850000

For result processing, preserve the original previous.jsonl. profile/summary.json, trial/ab.jsonl and trial/stem.log are inputs to summarize.py. These four profiles sampled actual instruction addresses at 1 ms CPU timer requests, only inside the two timed rendering calls. Linux timer granularity affects the resulting sample counts. Each profiler process observed exactly six timer boundary calls per block. Both debug objects' loaded .text bytes matched the stock objects before the instruction-level source mapping. Instrumented time is excluded from both stock timing sweeps.

## Experimental 909 triangle diode

The saved trial/triangle.patch bypasses the general saturator's range check only where a triangle-wave input and fixed 1.6 or 2.0 gain guarantee an in-range table lookup. Five affected voices and the complete kit each ran through 8,192 paired 256-frame blocks. Every output bus and the complete 909 state matched at every block. The two renderers share immutable ADPCM sample addresses in the paired test. Four all-engine bank/sweep cases were also tested across 16 alternating stock/candidate pairs. Each audio and meter file matched the historical checksum. All 80 allocated sections in each stock comparison object matched the corresponding object from the full Elite and Pro native builds. Both stock-board toolchain invocations reduced the candidate's d9_render text by 104 bytes with unchanged data and BSS. The paired timing results in verified.json do not establish a playback speedup. The experimental change was excluded from firmware.

The profile and triangle investigation scripts use the recorded workspace layout, with this extracted directory named i3-results beside integ-playback, nightly and deps/jieli-linux-toolchains-20260730.1. The following commands reproduced the investigations after building stock.

    cc -O2 -Wall -Wextra -Werror -fPIC -shared profile/sample.c -ldl -o profile/sample.so
    python3 profile/run.py
    python3 profile/debug.py 1 2
    python3 profile/lines.py
    python3 triangle-trial.py
    python3 trial/ab.py
    python3 trial/native.py
    nm -g --defined-only objects/01-drum909.o | awk '{print $3" ref_"$3}' >trial/rename.sym
    objcopy --redefine-syms=trial/rename.sym objects/01-drum909.o trial/ref909.o
    cc -std=c99 -O2 -ffp-contract=off -I../integ-playback/firmware/src -I../integ-playback/firmware/src/dsp -I../integ-playback/build/gen trial/stem.c trial/ref909.o trial/01-drum909.o ../integ-playback/firmware/src/dsp/x0x_param.c -lm -o trial/stem
    taskset -c 4 trial/stem >trial/stem.log

The profiler's initial run inherited a live interval timer through taskset's exec and ended on SIGPROF. The recorded successful profiles set affinity before loading the sampler in the target executable. The initial paired 909 comparison used distinct immutable sample addresses in the two states. Sharing those original addresses let the test compare every remaining state byte directly and retain all four PCM comparisons.
