#include "drum808.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
extern void ref_drum808_init(drum808_t *);
extern void ref_drum808_trigger(drum808_t *,int,float);
extern void ref_drum808_set(drum808_t *,int,int,int);
extern void ref_drum808_render_st_masked(drum808_t *,float *,float *,float *,float *,int,uint16_t);
extern void ref_drum808_render_st_lanes(drum808_t *,float *,float *,float *,float *,int,uint16_t,uint32_t);
extern void ref_drum808_metal_prepare(drum808_t *,float [4][256],int,uint16_t);
extern void ref_drum808_finish_rest(drum808_t *,const float [4][256],float *,float *,float *,float *,int,uint16_t);
static const int sizes[]={0,1,2,3,7,31,32,33,63,127,255,256};
static void check(const void *a,const void *b,size_t len,int mode,int block,const char *what) {
 if(memcmp(a,b,len)) {fprintf(stderr,"%s mismatch, mode %d block %d\n",what,mode,block);assert(0);}
}
static void seed_history(drum808_t *s,unsigned i) {
 d8_bq_t *const f[]={&s->cp.hp,&s->cy.body_sk,&s->cy.top_hp,&s->cy.out_hp,&s->ch.ska,&s->ch.skb,&s->oh.ska,&s->oh.skb};
 const uint32_t bits[]={0x80000000,0x00000000,0x807fffff,0x00000001,0x80000001,0x3f400000,0xbf000000,0x007fffff};
 for(unsigned j=0;j<8;j++) {
  assert(memcmp(&f[j]->n0,&f[j]->n2,4)==0);
  memcpy(&f[j]->z1,&bits[(i+j)%8],4);memcpy(&f[j]->z2,&bits[(i+3+j)%8],4);
 }
}
int main(void) {
 unsigned total=0, events=0, input_cases=0;
 for (int mode=0;mode<2;mode++) {
  drum808_t a,b;memset(&a,0,sizeof a);memset(&b,0,sizeof b);ref_drum808_init(&a);drum808_init(&b);
  check(&a,&b,sizeof a,mode,-1,"whole initialized state");
  for(int block=0;block<1536;block++) {
   const int n=sizes[block%12];
   uint16_t mask=(block%5==0 ? 0 : block%5==1 ? 0x7ff : (uint16_t)((block*1039u)%2048u));
   for(int t=0;t<=D8_KIT;t++) {
    int count=drum808_nparams(t),p=(block+t)%count;const x0x_param_t *param=drum808_param(t,p);assert(param);
    int value=(block/count)%3==0 ? 0 : (block/count)%3==1 ? param->max : (block*29+t)%(param->max+1);
    ref_drum808_set(&a,t,p,value);drum808_set(&b,t,p,value);events++;
    if(t<D8_NUM && (block%8==0 || (block+t)%7==0)) {
     float v=(float)((block+t*3)%128)/127.0f;
     ref_drum808_trigger(&a,t,v);drum808_trigger(&b,t,v);
    }
   }
   if(block%19==0) {seed_history(&a,block);seed_history(&b,block);input_cases++;}
   float out[2][4][256],raw[2][4][256]={0};
   for(unsigned bus=0;bus<4;bus++) for(unsigned j=0;j<256;j++) out[0][bus][j]=(j&1?-1.0f:1.0f)*(float)((block+bus+j)%17)*0.03125f;
   memcpy(out[1],out[0],sizeof out[0]);
   if(mode==0) {
    ref_drum808_render_st_masked(&a,out[0][0],out[0][1],out[0][2],out[0][3],n,mask);
    drum808_render_st_masked(&b,out[1][0],out[1][1],out[1][2],out[1][3],n,mask);
   } else {
    ref_drum808_metal_prepare(&a,raw[0],n,mask);drum808_metal_prepare(&b,raw[1],n,mask);
    check(raw[0],raw[1],sizeof raw[0],mode,block,"split raw PCM");
    ref_drum808_render_st_lanes(&a,out[0][0],out[0][1],out[0][2],out[0][3],n,mask,D8_LANES_BODY);
    drum808_render_st_lanes(&b,out[1][0],out[1][1],out[1][2],out[1][3],n,mask,D8_LANES_BODY);
    ref_drum808_finish_rest(&a,raw[0],out[0][0],out[0][1],out[0][2],out[0][3],n,mask);
    drum808_finish_rest(&b,raw[1],out[1][0],out[1][1],out[1][2],out[1][3],n,mask);
   }
   check(out[0],out[1],sizeof out[0],mode,block,"four PCM buses");
   check(&a,&b,sizeof a,mode,block,"whole state");total++;
  }
 }
 printf("PASS mode=whole+split blocks=%u parameter_updates=%u signed_history_cases=%u state_bytes=%zu\n",total,events,input_cases,sizeof(drum808_t));
}
