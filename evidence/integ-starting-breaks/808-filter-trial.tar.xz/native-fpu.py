"""Decode production-linked functions using the shipping CPU and FPU selections."""
from pathlib import Path
import collections
import json
import re
import subprocess
w = Path(__file__).resolve().parent
top = w.parents[1]
tool = top / 'deps/jieli-linux-toolchains-20260730.1/common/bin/objdump'
summary = {}
for model, board in [('elite', 'smk37-elite'), ('pro', 'smk37')]:
    root = w / ('native-' + model)
    summary[model] = {}
    for arm, elf in [('stock', top / 'firmware/build' / board / 'x0x.elf'), ('trial', root / 'trial.elf')]:
        table = subprocess.check_output([tool, '-t', elf], text=True)
        symbols = {v[-1]: (int(v[0], 16), int(v[-2], 16)) for line in table.splitlines()
                   if (v := line.split()) and len(v) >= 6 and v[-1] in ('cp_run', 'cy_run', 'hat_run')}
        assert len(symbols) == 3
        summary[model][arm] = {}
        for name, (start, size) in symbols.items():
            dis = subprocess.check_output([tool, '-d', '-mcpu=r3', '-mattr=+fprev1', '-j', '.text',
                                           f'--start-address={start:#x}', f'--stop-address={start+size:#x}', elf], text=True)
            lines = [line for line in dis.splitlines() if (m:=re.match(r'^\s*([0-9a-f]+):\s', line)) and start <= int(m.group(1),16) < start+size]
            assert int(lines[0].split(':')[0], 16) == start, (name, start, lines[:2])
            assert int(lines[-1].split(':')[0], 16) < start + size
            (root / f'{arm}-{name}.s').write_text('\n'.join(lines) + '\n')
            summary[model][arm][name] = {'symbol_bytes':size, 'decoded_lines':len(lines),
                'unknown_lines':sum('<unknown instruction>' in line for line in lines),
                'float_multiply':sum(bool(re.search(r'\*\s*r\d+\s*\(f\)', line)) for line in lines)}
for model, d in summary.items():
    for name in d['stock']:
        print(model, name, d['stock'][name], d['trial'][name])
(w / 'native-fpu.json').write_text(json.dumps(summary, indent=2) + '\n')
