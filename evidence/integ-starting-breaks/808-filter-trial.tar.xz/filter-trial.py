from pathlib import Path
import re,subprocess
w=Path(__file__).resolve().parent
root=w.parent/'integ-playback'
a=w/'filter';a.mkdir(exist_ok=True)
source=(root/'firmware/src/dsp/drum808.c').read_text()
def swap(old,new):
 global source
 assert source.count(old)==1,old
 source=source.replace(old,new)
for name,field,x,y in [('hp','hp','y','hy'),('sk','body_sk','hpa_y','yy'),('th','top_hp','body_pre','yy'),('oh','out_hp','y','yy'),('ska','ska','hp','yy'),('skb','skb','yy','sv')]:
 swap(f', {name}_n2 = v->{field}.n2;', ';')
 swap(f'        {y} = {name}_n0 * {x} + {name}_z1;', f'        bx = {name}_n0 * {x};\n        {y} = bx + {name}_z1;')
 swap(f'({name}_n2 * {x} - {y})', f'(bx - {y})')
swap('float t1 = bus_x - d1, hp, e, sv, yy;', 'float t1 = bus_x - d1, hp, e, sv, yy, bx;')
swap('/* bq_run(&v->hp, y) */','/* The high-pass has n2 == n0; the same rounded product feeds both taps. */')
swap('/* hp1 body_hpa, then bq body_sk */','/* Each SK high-pass has n2 == n0. Reuse its rounded input product. */')
swap('/* bq ska then skb, as bq_run(&skb, bq_run(&ska, ...)) */','/* Both SK high-passes have n2 == n0. Reuse each rounded input product. */')
candidate=a/'drum808.c';candidate.write_text(source)
prefix=(w/'build-objects.py').read_text().split('o=w/')[0]
exec(compile(prefix,str(w/'build-objects.py'),'exec'))
obj=a/'02-drum808.o'
subprocess.run(['cc',*flags,'-c',str(candidate),'-o',str(obj)],check=True)
objects=sorted((w/'objects').glob('*.o'));assert len(objects)==72 and objects[2].name==obj.name
objects[2]=obj
subprocess.run(['cc',*map(str,objects),'-lm','-o',str(a/'run')],check=True)
print(subprocess.check_output(['size',str(w/'objects'/obj.name),str(obj)],text=True))
raw=subprocess.run(['diff','-u','--label','a/firmware/src/dsp/drum808.c','--label','b/firmware/src/dsp/drum808.c',str(root/'firmware/src/dsp/drum808.c'),str(candidate)],capture_output=True).stdout
(a/'filter.patch').write_bytes(raw)
