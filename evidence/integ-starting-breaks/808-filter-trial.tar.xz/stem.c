#define _POSIX_C_SOURCE 200809L
#include "drum808.h"
#include <assert.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
extern void ref_drum808_init(drum808_t *);
extern void ref_drum808_trigger(drum808_t *,int,float);
extern void ref_drum808_render_st_masked(drum808_t *,float *,float *,float *,float *,int,uint16_t);
static int64_t ns(void) { struct timespec t;assert(!clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t));return t.tv_sec*INT64_C(1000000000)+t.tv_nsec; }
int main(void) {
 for(int mode=0;mode<2;mode++) for(int repeat=0;repeat<16;repeat++) {
  drum808_t state[2];memset(state,0,sizeof(state));ref_drum808_init(&state[0]);drum808_init(&state[1]);
  assert(!memcmp(&state[0],&state[1],sizeof state[0]));
  int64_t total[2]={0};
  for(int block=0;block<512;block++) {
   float out[2][4][256]={0};
   if(block%9==0) for(int voice=0;voice<D8_NUM;voice++) {
    if (mode==1 && voice!=D8_CY && voice!=D8_CH && voice!=D8_OH && voice!=D8_CP) continue;
    float vel=(float)(48+((block+voice*13)%79))/127.0f;
    ref_drum808_trigger(&state[0],voice,vel);drum808_trigger(&state[1],voice,vel);
   }
   for(int j=0;j<2;j++) {
    int arm=(j+block+repeat)%2;float (*y)[256]=out[arm];
    int64_t start=ns();
    if(arm==0) ref_drum808_render_st_masked(&state[0],y[0],y[1],y[2],y[3],256,0x7ffu);
    else drum808_render_st_masked(&state[1],y[0],y[1],y[2],y[3],256,0x7ffu);
    total[arm]+=ns()-start;
   }
   if(memcmp(out[0],out[1],sizeof out[0])||memcmp(&state[0],&state[1],sizeof state[0])) {
    fprintf(stderr,"PCM/state mismatch, mode=%d repeat=%d block=%d\n",mode,repeat,block);return 2;
   }
  }
  printf("%d %d %" PRId64 " %" PRId64 "\n",mode,repeat,total[0],total[1]);
 }
}
