from collections import defaultdict
from pathlib import Path
from statistics import median
import hashlib,json,re
w=Path(__file__).resolve().parent
def readrows(p):return [json.loads(l) for l in p.read_text().splitlines()]
expected={(tuple(p['banks']),p['sweep']):p['traces'] for p in readrows(w.parent/'previous.jsonl')}
out={'source':'bbef756236ddf54cebaf8ccf9071b8975e7e8839','paired_stem':{},'host_text_delta_bytes':-128,'host_data_delta_bytes':0,'host_bss_delta_bytes':0}
for k,swapped,n in [('stem',False,512),('reverse-stem',True,1024)]:
 d=defaultdict(list);repeat=set()
 for row in (w/(k+'.log')).read_text().splitlines():
  m,r,x,y=map(int,row.split())
  assert (m,r) not in repeat
  repeat.add((m,r));d[m].append(x/y if swapped else y/x)
 count=24 if swapped else 16
 if len(repeat)!=2*count:continue
 out['paired_stem'][k]={}
 for m,values in d.items():
  assert len(values)==count
  out['paired_stem'][k]['affected_lines' if m else 'all_voices']={'blocks':len(values)*n,'paired_batches':len(values),'candidate_faster_batches':sum(1 for v in values if v<1),'median_candidate_stock_time_ratio':median(values),'range':[min(values),max(values)]}
p=w/'matrix.jsonl'
if p.exists():
 cases=readrows(p)
 assert len(cases)<=32
 for x in cases:
  assert x['status']==0 and x['blocks']==1024 and 'audible=31 drum_masks=2047/2047' in x['stderr']
  assert x['traces']==expected[tuple(x['banks']),x['sweep']]
 assert len(set((tuple(e['banks']),e['sweep']) for e in cases))==len(cases)
 out['candidate_matrix']={'cases':len(cases),'pcm_digest_matches':len(cases),'meter_digest_matches':len(cases),'blocks':sum(x['blocks'] for x in cases)}
(w/'verified.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
