from pathlib import Path
import hashlib,json,tarfile,io,re,subprocess
w=Path(__file__).resolve().parent
p=w.parents[1]/'logs/integ-bbef7562-808-filter-trial.tar.xz'
subprocess.run(['python3',str(w/'compare.py')],check=True,stdout=subprocess.DEVNULL)
result=json.loads((w/'verified.json').read_text());rows=[json.loads(l) for l in (w/'matrix.jsonl').read_text().splitlines()]
assert len(rows)==32 and len(result['paired_stem'])==2 and result['candidate_matrix']['pcm_digest_matches']==32
q=result['candidate_matrix'];q.update({'deadline_us':11609,'cpu':3,'activity':'ordinary, concurrent builds'})
def val(x,k):return float(re.search(r'\b'+k+r'=([0-9.]+)\b',x['stderr']).group(1))
for k,op in [('CPU_misses',sum),('wall_misses',sum),('CPU_peak_us',max),('wall_peak_us',max)]:
 v=op(val(x,k) for x in rows);q[k]=int(v) if 'misses' in k else v
for k in ('drum808.c','filter.patch','run'):result[k+'_sha256']=hashlib.sha256((w/k).read_bytes()).hexdigest()
result['automation']=(w/'automation.log').read_text().strip()
(w/'verified.json').write_text(json.dumps(result,indent=2)+'\n')
names='verified.json matrix.jsonl matrix.log matrix-before-disconnect.jsonl matrix-recovery.jsonl matrix-recovery.log resume.py automation.c automation.log stem.c stem.log reverse-stem.c reverse-stem.log filter.patch compare.py native-relink.py native-relink.log native-results.json native-fpu.py native-fpu.json matrix-before-disconnect.log run-matrix.py drum-pan.log pack.py README.md'.split()
items={n:(w/n).read_bytes() for n in names}
items['filter-trial.py']=(w.parent/'filter-trial.py').read_bytes()
for f in sorted(w.glob('native-*/*.s')):items[str(f.relative_to(w))]=f.read_bytes()
assert sum(n.endswith('.s') for n in items)==12
with tarfile.open(p,'w:xz',preset=5) as t:
 for k,data in sorted(items.items()):
  ti=tarfile.TarInfo(k);ti.size=len(data);t.addfile(ti,io.BytesIO(data))
print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest(),q)
