from pathlib import Path
import os,sys,subprocess,hashlib,json,re
w=Path(__file__).resolve().parent
root=w.parents[1]/'integ-playback'
orig=w.parents[1]/'firmware'
os.chdir(root)
sys.path.insert(0,str(root/'tools'))
td=root.parent/'deps/jieli-linux-toolchains-20260730.1'
os.environ['JIELI_TOOLCHAIN']=str(td)
tmp=w/'tmp';tmp.mkdir(exist_ok=True);os.environ['TMPDIR']=str(tmp)
import build
state={}
class Done(Exception):pass
def capture(*cmds):
 found=[c for c in cmds if c[0]=='cc' and any(str(a).endswith('/dsp/drum808.c') for a in c)]
 assert len(found)==1
 state['compile']=list(found[0][1:])
def intercept(tool,*args):
 if tool!='pi32v2/bin/ld':raise ValueError(tool)
 state['link']=list(args)
 raise Done
build.tc_all=capture;build.tc=intercept;build.BOARD='smk37'
results={}
for model,dname in [('elite','smk37-elite'),('pro','smk37')]:
 build.MODEL=model;build.PRODUCT=build.MODELS[model]+'_900'
 build.BOARD_DEFS['smk37']=['-DBOARD_SMK37=1']+([f'-DSMK_MODEL="{build.MODELS[model]}"'] if model!='pro' else [])
 stock=orig/'build'/dname;target=w/f'native-{model}';target.mkdir(exist_ok=True)
 build.OUT=root/'build'/('playback-trial-'+model)
 try:build.build_app()
 except Done:pass
 cmd=state['compile'][:]
 stock_args=list(map(str,cmd));stock_args[stock_args.index('-c')+1]='firmware/src/dsp/drum808.c'
 stock_args[stock_args.index('-o')+1]=str(target/'stock-808.o')
 subprocess.run([str(td/'pi32v2/bin/clang'),'-target','pi32v2',*stock_args],cwd=orig,check=True)
 matches=(target/'stock-808.o').read_bytes()==(stock/'o2/dsp_drum808.o').read_bytes()
 print(model,'recompiled stock 808 bitcode equals full board build',matches,flush=True)
 cmd[cmd.index('-c')+1]=str(w/'drum808.c');cmd[cmd.index('-o')+1]=str(target/'drum808.o')
 cmd=[str(td/'pi32v2/bin/clang'),'-target','pi32v2','-iquote',str(root/'firmware/src/dsp'),*map(str,cmd)]
 subprocess.run(cmd,check=True)
 params=state['link'][:];params[params.index('-T')+1]=str(stock/'app.ld')
 for i,v in enumerate(params):
  if isinstance(v,Path) and v.suffix=='.o':
   params[i]=str(target/'drum808.o') if v.name=='dsp_drum808.o' else str(stock/v.relative_to(build.OUT))
 elf=target/'trial.elf';params[params.index('-o')+1]=str(elf)
 subprocess.run([str(td/'pi32v2/bin/ld'),*map(str,params)],check=True)
 def sections(path):
  text=subprocess.check_output([str(td/'common/bin/objdump'),'-h',str(path)],text=True)
  return {k:int(n,16) for k,n in re.findall(r'^\s*\d+\s+(\.\w+)\s+([0-9a-f]+)\s',text,flags=re.M)}
 def symbols(path):
  text=subprocess.check_output([str(td/'common/bin/objdump'),'-t',str(path)],text=True)
  hits={}
  for row in text.splitlines():
   v=row.split()
   if len(v)>=6 and v[-1] in ('cp_run','hat_run','cy_run'):
    hits[v[-1]]={'address':int(v[0],16),'size':int(v[-2],16)}
  assert len(hits)==3,(path,hits)
  return hits
 def disassemble(path,d,arm):
  text=subprocess.check_output([str(td/'common/bin/objdump'),'-d',str(path)],text=True)
  lines=text.splitlines()
  record={}
  for name,h in d.items():
   start=h['address'];end=start+h['size'];code=[]
   for line in lines:
    m=re.match(r'^\s*([0-9a-fA-F]+):\s',line)
    if m and start<=int(m.group(1),16)<end:code.append(line)
   assert code,(name,h)
   (target/f'{arm}-{name}.s').write_text('\n'.join(code)+'\n')
   record[name]={'symbol_bytes':h['size'],'disassembly_lines':len(code)}
  return record
 ab={}
 for arm,path in [('stock',stock/'x0x.elf'),('trial',elf)]:
  ab[arm]={'sections':sections(path),'functions':disassemble(path,symbols(path),arm),'elf_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 ab['stock_808_bitcode_exact']=matches;results[model]=ab
 (w/'native-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(model,{f:ab['trial']['sections'][f]-ab['stock']['sections'][f] for f in ('.text','.ram_text','.c1_text','.data','.bss')},ab['trial']['functions'],flush=True)
