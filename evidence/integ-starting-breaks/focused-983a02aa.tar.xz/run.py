"""Run against the exact shared checkout and isolate the test whose outputs are in build/."""
from pathlib import Path
import hashlib, json, os, re, subprocess, sys, tempfile, time

out = Path(__file__).resolve().parent
workspace = out.parent.parent
repo = workspace / 'integ-publish'
head = '983a02aa396e481209cf1cee6f495f7df5d27a79'
env = {**os.environ, 'GIT_OPTIONAL_LOCKS':'0', 'PYTHONDONTWRITEBYTECODE':'1'}
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, env=env)
assert git('rev-parse', 'HEAD').decode().strip() == head
assert not git('diff', '--name-only', head, '--', 'tests', 'tools', 'firmware', 'assets', 'docs/one-build-integration-inventory.json')
results = {'commit':head, 'tree':git('rev-parse', 'HEAD^{tree}').decode().strip(), 'cases':[], 'isolation':{}}
with tempfile.TemporaryDirectory(prefix='pr976-focused-', dir=workspace/'deps/tmp') as td:
    tmp = Path(td)
    env['TMPDIR'] = td
    results['temporary_directory'] = td
    fixture = tmp/'exact-source-fixture'
    fixture.mkdir()
    paths=['assets/factory-breaks','tests/brk_pack_test.c','tests/break_pack_test.py','tools/break_pack.py','firmware/src/app/brk_pack.h']
    inputs=git('ls-tree','-r','-z',head,'--',*paths)
    manifest=[]
    for record in inputs.rstrip(b'\0').split(b'\0'):
        meta, rawname=record.split(b'\t',1)
        mode,kind,oid=meta.decode().split()
        assert kind=='blob' and mode.startswith('100')
        name = rawname.decode(); contents = git('cat-file','blob',oid)
        assert hashlib.sha1(b'blob '+str(len(contents)).encode()+b'\0'+contents).hexdigest()==oid
        dest=fixture/name; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(contents)
        manifest.append({'path':name,'git_blob':oid, 'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
    results['isolation'] = {'fixture':str(fixture), 'source_files':manifest, 'reason':'break_pack_test.py writes fixed ROOT/build header, blob, and host reader binary. Only its private fixture receives those writes.'}
    (fixture/'build').mkdir()
    for label,cwd,args,count_regex in [
      ('package-stock-loops',repo,['python3','tests/package_stock_loops_test.py'],r'^PASS '),
      ('break-pack',fixture,['python3','tests/break_pack_test.py'],r'\bok$'),
      ('original-build-composition',repo,['python3','tests/host/test_original_build_composition.py','-v'],r' \.\.\. ok$'),
      ('one-build-integration-plan',repo,['python3','tests/test_one_build_integration_plan.py','-v'],r' \.\.\. ok$'),
    ]:
        start=time.monotonic()
        with (out/(label+'.log')).open('wb') as log:
            result=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
        data=(out/(label+'.log')).read_bytes()
        row={'label':label, 'cwd':str(cwd), 'command':args,'exit':result.returncode,'passed_reported':len(re.findall(count_regex,data.decode(),flags=re.M)), 'elapsed_seconds':round(time.monotonic()-start,3), 'sha256':hashlib.sha256(data).hexdigest()}
        results['cases'].append(row)
        print(label, row['exit'], row['passed_reported'],flush=True)
assert git('rev-parse','HEAD').decode().strip()==head
(out/'receipt.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(int(any(c['exit'] or c['passed_reported']<=0 for c in results['cases'])))
