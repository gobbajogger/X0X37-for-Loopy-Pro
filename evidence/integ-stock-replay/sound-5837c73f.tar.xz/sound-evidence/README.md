# Stock Sound integration replay

Both models used stock Sound source 5837c73f754a667c526edd420aefbe7cf3a071bf, based on consolidated 468744971720a81a536308e3bd84bd8766a5ed0f. The independent Sound reference at 2fe5930c161a30c907a4b91991ab3c9724380b10 identifies the same source. The integration PR's differences against this consolidated base affect documentation, tests and issue forms. The production image inputs match.

## Builds and sample placement

With the supplied JieLi 20260730.1 tools, the three pinned AC79 SDK files, the ten active original inputs and writable local temporary directories, invoke build.sh in separate trees with MODEL=elite and MODEL=pro. The reproducible results here use the successful Elite build and the clean two-core Pro retry. The parser checked model identity, stock head and partition layout and the CRCs. The native-verification receipt compares eight hashes. The fit replay rebuilt the C reader, checked all five canonical WAV, ADPCM and decoded identities, exercised all 62 attempted placements, and checked both capacity boundaries.

## Sound tests

The native Juno production runtime exercised six voices, sustain, release and output. The three BREAK probability tests include generator and original-table equivalence and two corrupted arithmetic controls. The timing harness measures 1,024 blocks in each of 16 ordered bank pairs under two workloads using the repository audio path and the pinned BR1 WAV. Only local paths in the archived harness scripts were adapted. Both published independent runs of the same production inputs reproduced all 32 audio hashes and all 32 meter and scope hashes in this replay. The same-core fixed-work control ran after the matrix on CPU 7 with 32,768 blocks and 850,000 dependent unsigned arithmetic iterations per block.

## Framebuffer and refs

The FREE PLAY evidence preserves earlier timeouts, final genuine GCC and ccache statistics, distinct binaries for all four cases, and exit 0 of the unchanged wrapper. These tests used the integration source at 711df7b3 and its actual 100-second per-case deadlines. The read-only I7 audit covered both repositories' historical CSV inventories, current branch and protected PR heads, archive refs, and the ancestor witnesses listed in the receipt.
