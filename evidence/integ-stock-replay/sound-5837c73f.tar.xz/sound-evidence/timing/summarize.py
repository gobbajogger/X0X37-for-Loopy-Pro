from pathlib import Path
import json
import hashlib
import re

base = Path("qual/ns-timing")
rows = [json.loads(line) for line in (base / "full/matrix.jsonl").read_text().splitlines()]
negative = json.loads((base / "full/negative.jsonl").read_text())
assert len(rows) == 32 and len({(*r["banks"],r["sweep"]) for r in rows}) == 32
assert negative["status"] == 3 and "audible=23 " in negative["stderr"]
stats = []
for r in rows:
    assert r["status"] == 0 and r["blocks"] == 1024 and "audible=31 drum_masks=2047/2047" in r["stderr"], r
    assert r["traces"]["audio.i32"][0] == 1024 * 4096
    m = re.search(r"CPU_peak_us=([\d.]+) wall_peak_us=([\d.]+) CPU_misses=(\d+) wall_misses=(\d+)",r["stderr"])
    assert m, r["stderr"]
    stats.append(dict(banks=r["banks"],sweep=r["sweep"],cpu_peak_us=float(m[1]),wall_peak_us=float(m[2]),cpu_misses=int(m[3]),wall_misses=int(m[4])))
report = dict(source="5837c73f754a667c526edd420aefbe7cf3a071bf", threshold_us=11609,
              affinity=[7], blocks=sum(r["blocks"] for r in rows), cases=len(rows),
              cpu_misses=sum(x["cpu_misses"] for x in stats),wall_misses=sum(x["wall_misses"] for x in stats),
              cpu_peak_us=max(x["cpu_peak_us"] for x in stats),wall_peak_us=max(x["wall_peak_us"] for x in stats),
              five_part_mask=31,kit_row_masks=[2047,2047],muted_B_returncode=negative["status"],muted_B_mask=23,
              runner_sha256=hashlib.sha256((base/"full/run").read_bytes()).hexdigest(), measurements=stats)
(base/"summary.json").write_text(json.dumps(report,indent=2)+"\n")
print({k:v for k,v in report.items() if k!='measurements'})
