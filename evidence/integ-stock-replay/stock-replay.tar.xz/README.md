# Stock firmware replay

The two native builds and the audio harness use DnBOX combined source `b5207372b5d342575b70b651b7dd413527c2f161`. This includes Sound `63278e33` and FWUI `9dd6f2df`. The focused runner and roadmap tests use firmware integration `2d9f05d6b7368b9e240d3b019934ebf9c1efc080` and consolidated `468744971720a81a536308e3bd84bd8766a5ed0f`.

## Builds and samples

Both builds invoked the stock `build.sh` with `MODEL=elite` or `MODEL=pro`, the supplied JieLi 20260730.1 compiler, the three SHA-256-pinned AC79 inputs and all ten original sound inputs. Both exited 0. The independent package verifier compared the app, ELF, loader and firmware package with all eight entries of the retained b5207372 manifest. It also ran the registered stock SMK package checker on both packages and compiled a new C BREAK reader. The pack replay exercised every nonempty subset of the five original zones on each model.

- [Published combined source](https://github.com/gobbajogger/DnBOX/commit/b5207372b5d342575b70b651b7dd413527c2f161)
- [Retained packages, build manifest and BREAK replay](https://github.com/gobbajogger/DnBOX/tree/0f5171501677793ddd3a5318cc00bba6199bb9ca/artifacts/integ-candidates/b5207372)

## Heavy playback

The driver patch, flags, workloads, four-bank pair order and original sample match the prior three-lane qualification. The stock zero-loop header has SHA-256 `b114be3c1c1f2019f6b920a732a17d4ce47ba203ac3505a93c65c67da1e2a3f0`. GCC 14.2.0 produced the instrumented harness with SHA-256 `14b30649aa0c91e2f98eb38a567edec94f2f54f734f0a48a25520bf8d140c8e2`. Both runs used CPU 6 at normal scheduling priority. Each run covered all 16 ordered pairs and both workloads for 1,024 blocks per case. The muted-bass control returned status 3 with audible mask 23.

The first entry in timing/comparison.json is the archived reference. The second and third entries are these two new runs. A successful harness process verifies trace output and part activity. Deadline failures are counted independently from the raw CPU and wall-clock measurements. The separately compiled fixed-work control used 32,768 blocks of 850,000 dependent iterations with unchanged instructions and input.

[Original harness, driver preparation and verifier](https://github.com/gobbajogger/DnBOX/blob/70d0cf6bffd8a2d9eacdd8756a2119a6cd58ac47/evidence/integ-b5207372/heavy-playback.tar.xz)

## Focused firmware checks

The tracked scheduler tests exercised capacity, admission and overlay selection. The registered roadmap tests exercised state generation, malformed state, ancestry and stale output. The generator also passed `--check --integration-sha 468744971720a81a536308e3bd84bd8766a5ed0f` using the verified local Git commit object. The post-merge full host and strict emulator gates remain outstanding.

Across a six-second sample of all nine allowed CPUs, CPU 2 had the lowest measured busy fraction. Repeating the same fixed-work control there recorded 345 misses. CPU 6 recorded 293. Both controls completed with the same integer state. The host results leave I3 open.
