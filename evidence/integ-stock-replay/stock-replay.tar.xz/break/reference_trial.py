"""Minimum number of literal or prior-substring tokens to recover an exact BREAK bank.

Every literal or arbitrary-length copy costs just one token. Copy source and length
are free, and an earlier output match may overlap the destination (LZ semantics).
The immutable copy dictionary is the entire actual linked application.
"""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import itertools
import json
import sys

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "nightly/web/product-site/assets/starting-breaks"
sys.path[:0] = [str(ROOT / "fw/tools"), str(ASSETS)]
import break_pack
import verify_assets


def coverage(app, bank):
    # For every length-1 or length-2 prefix, only need membership. For longer
    # matches enumerate every starting offset with the same three-byte prefix.
    first_pair = {}
    triples = defaultdict(list)
    for source_id, data in enumerate([app, bank]):
        for i in range(len(data)-1):
            pair = data[i:i+2]
            first_pair.setdefault(pair, (source_id, i))
            if i + 2 < len(data):
                triples[data[i:i+3]].append((source_id, i))
    pos = 0
    count = 0
    longest = 0
    decoded = bytearray()
    while pos < len(bank):
        best = 1
        witness = None
        pair = first_pair.get(bank[pos:pos+2])
        if pair is not None and pair < (1, pos):
            best, witness = 2, pair
        for source_id, at in triples.get(bank[pos:pos+3], ()):
            if source_id == 1 and at >= pos:
                break
            data = bank if source_id else app
            length = 3
            limit = min(len(data)-at, len(bank)-pos)
            while length < limit and data[at+length] == bank[pos+length]:
                length += 1
            if length > best:
                best, witness = length, (source_id, at)
        if witness is None:
            decoded.append(bank[pos])
        else:
            source_id, at = witness
            data = decoded if source_id else app
            for i in range(best):
                decoded.append(data[at+i])
        longest = max(longest,best)
        count += 1
        pos += best
    assert decoded == bank
    return count, longest


def exhaustive(app, bank):
    # All valid choices at all positions, independently minimized.
    costs = [len(bank)+1] * len(bank) + [0]
    for pos in reversed(range(len(bank))):
        costs[pos] = 1 + costs[pos+1]
        for stop in range(pos+2, len(bank)+1):
            phrase = bank[pos:stop]
            previous = bank.find(phrase)
            if phrase in app or (0 <= previous < pos):
                costs[pos] = min(costs[pos], 1+costs[stop])
    return costs[0]


def run():
    cases = 0
    for size in range(8):
        for sequence in itertools.product(b"ab", repeat=size):
            for app in [b"", b"aa", b"aaaabbbc", b"b"]:
                bank = bytes(sequence)
                assert coverage(app, bank)[0] == exhaustive(app, bank)
                cases += 1
    c = verify_assets.load_contract(ASSETS)
    loops = []
    for a in c["assets"]:
        data = (ASSETS / (a["id"]+".adpcm")).read_bytes()
        verify_assets.verify_encoded(a, data)
        loops.append(dict(name=a["name"], nsamples=a["frames"], bars=1, adpcm=data))
    bank = break_pack.encode_pack(loops, c["rate"])
    info = json.loads((ROOT/"replay.json").read_text())
    assert sha256(bank).hexdigest() == info["bank_sha256"]
    result = dict(source=info["source"], bank_sha256=info["bank_sha256"],
                  bank_bytes=len(bank), independent_short_controls=cases, models={})
    for name, stats in info["models"].items():
        folder = "smk37-elite" if name=="elite" else "smk37"
        app = (ROOT/"fw/build"/folder/"x0x.bin").read_bytes()
        assert sha256(app).hexdigest() == stats["app_sha256"]
        count, longest = coverage(app, bank)
        result["models"][name] = dict(app_sha256=stats["app_sha256"], capacity=stats["usable"],
                                     minimum_tokens=count, longest_chosen_phrase=longest,
                                     shortfall_at_one_byte_per_token=count-stats["usable"])
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    run()
